package com.mihoon.dualshot

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.Size as AndroidSize
import android.net.Uri
import android.provider.MediaStore
import kotlin.math.max
import kotlin.math.min

/**
 * 이 앱이 저장한 사진(DualShot_*.jpg) 목록을 갤러리에서 읽어온다.
 * 덕분에 방금 찍은 것뿐 아니라 이전에 찍은 사진도 앱 안에서 넘겨볼 수 있다.
 */
object ShotGallery {

    data class Shot(val uri: Uri, val name: String, val label: String)

    /** 최신 순으로 정렬된 목록 */
    fun load(context: Context): List<Shot> {
        val shots = ArrayList<Shot>()
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME
        )
        val selection = "${MediaStore.Images.Media.DISPLAY_NAME} LIKE ?"
        val args = arrayOf("DualShot%")
        val order = "${MediaStore.Images.Media.DATE_ADDED} DESC, ${MediaStore.Images.Media._ID} DESC"

        try {
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection, selection, args, order
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val name = c.getString(nameCol) ?: continue
                    val uri = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id
                    )
                    shots.add(Shot(uri, name, labelOf(context, name)))
                }
            }
        } catch (e: Exception) {
            // 조회 실패 시 빈 목록
        }
        return shots
    }

    /** 이 앱으로 찍은 동영상 목록 (최신 순) */
    fun loadVideos(context: Context): List<Shot> {
        val shots = ArrayList<Shot>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME
        )
        val selection = "${MediaStore.Video.Media.DISPLAY_NAME} LIKE ?"
        val args = arrayOf("DualShot%")
        val order = "${MediaStore.Video.Media.DATE_ADDED} DESC, ${MediaStore.Video.Media._ID} DESC"
        try {
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection, selection, args, order
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                while (c.moveToNext()) {
                    val name = c.getString(nameCol) ?: continue
                    val uri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI, c.getLong(idCol)
                    )
                    shots.add(Shot(uri, name, labelOf(context, name)))
                }
            }
        } catch (e: Exception) {
            // 조회 실패 시 빈 목록
        }
        return shots
    }

    /** 동영상의 첫 장면을 썸네일로 만들고 재생 표시를 얹는다 */
    fun loadVideoThumb(context: Context, uri: Uri, targetLongSide: Int): Bitmap? {
        val frame = videoFrame(context, uri, targetLongSide) ?: return null
        return withPlayBadge(frame)
    }

    private fun videoFrame(context: Context, uri: Uri, targetLongSide: Int): Bitmap? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                return context.contentResolver.loadThumbnail(
                    uri, AndroidSize(targetLongSide, targetLongSide), null
                )
            } catch (e: Exception) {
                // 아래 방법으로 다시 시도
            }
        }
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (e: Exception) {
            null
        } finally {
            try { retriever.release() } catch (e: Exception) { /* 무시 */ }
        }
    }

    private fun withPlayBadge(src: Bitmap): Bitmap {
        val out = try {
            src.copy(Bitmap.Config.ARGB_8888, true)
        } catch (e: Exception) {
            null
        } ?: return src

        val canvas = Canvas(out)
        val radius = min(out.width, out.height) * 0.24f
        val cx = out.width / 2f
        val cy = out.height / 2f

        canvas.drawCircle(cx, cy, radius, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(150, 0, 0, 0)
        })
        val triangle = Path().apply {
            moveTo(cx - radius * 0.32f, cy - radius * 0.48f)
            lineTo(cx - radius * 0.32f, cy + radius * 0.48f)
            lineTo(cx + radius * 0.55f, cy)
            close()
        }
        canvas.drawPath(triangle, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })

        if (out !== src) src.recycle()
        return out
    }

    /** 이 앱으로 찍은 가장 최근 동영상 */
    fun latestVideo(context: Context): Uri? {
        val projection = arrayOf(MediaStore.Video.Media._ID)
        val selection = "${MediaStore.Video.Media.DISPLAY_NAME} LIKE ?"
        val args = arrayOf("DualShot%")
        val order = "${MediaStore.Video.Media.DATE_ADDED} DESC, ${MediaStore.Video.Media._ID} DESC"
        return try {
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection, selection, args, order
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                if (c.moveToFirst()) {
                    ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, c.getLong(idCol))
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }

    fun latestPortrait(shots: List<Shot>): Shot? = shots.firstOrNull { it.name.contains("_V.") }
    fun latestLandscape(shots: List<Shot>): Shot? = shots.firstOrNull { it.name.contains("_H.") }

    private fun labelOf(context: Context, name: String): String = when {
        name.contains("_V.") -> context.getString(R.string.label_portrait)
        name.contains("_H.") -> context.getString(R.string.label_landscape)
        else -> context.getString(R.string.label_original)
    }

    /** 목록/썸네일용 축소 디코딩 */
    fun loadScaled(context: Context, uri: Uri, targetLongSide: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > targetLongSide) sample *= 2

            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            }
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }
}
