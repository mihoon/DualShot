package com.mihoon.dualshot

import android.content.ContentValues
import android.content.Context
import android.graphics.Matrix
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.MatrixTransformation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStream
import kotlin.math.roundToInt

/**
 * 녹화한 영상에서 원하는 비율의 영역만 잘라 새 영상을 만든다.
 * 자르는 위치는 시간에 따라 움직일 수 있어서, 녹화 중에 띠를 옮긴 것이 그대로 반영된다.
 */
@UnstableApi
object VideoCropper {

    private const val FOLDER = "DualShot"

    /** (녹화 시작 후 경과 시간(마이크로초), 위치 -1..1) */
    data class Keyframe(val timeUs: Long, val offset: Float)

    interface Callback {
        fun onProgress(percent: Int)
        fun onDone(output: File)
        fun onFailed(message: String)
    }

    /**
     * 시간에 따라 위치가 움직이는 잘라내기 효과.
     *
     * 들어온 영상 크기를 보고 목표 비율에 맞는 가장 큰 영역을 잡은 뒤,
     * 여유가 있는 축(보통 세로)을 따라 위치를 옮긴다.
     */
    class PanningCrop(
        /** 결과물의 가로/세로 비율 (16:9 이면 16f/9f) */
        private val targetAspect: Float,
        private val keyframes: List<Keyframe>
    ) : MatrixTransformation {

        private var halfW = 1f       // 잘라낸 영역의 폭 (원본 대비 비율)
        private var halfH = 1f       // 잘라낸 영역의 높이 (원본 대비 비율)
        private var panVertical = true

        override fun configure(inputWidth: Int, inputHeight: Int): Size {
            val inputAspect = inputWidth.toFloat() / inputHeight
            var outW: Int
            var outH: Int
            if (inputAspect > targetAspect) {
                outH = inputHeight
                outW = (inputHeight * targetAspect).roundToInt()
            } else {
                outW = inputWidth
                outH = (inputWidth / targetAspect).roundToInt()
            }
            // 인코더가 다루기 쉽도록 짝수로 맞춘다
            outW = (outW / 2 * 2).coerceIn(2, inputWidth)
            outH = (outH / 2 * 2).coerceIn(2, inputHeight)

            halfW = outW.toFloat() / inputWidth
            halfH = outH.toFloat() / inputHeight
            // 여유가 있는 쪽으로 움직인다
            panVertical = (1f - halfH) >= (1f - halfW)

            return Size(outW, outH)
        }

        override fun getMatrix(presentationTimeUs: Long): Matrix {
            val offset = offsetAt(presentationTimeUs)
            // NDC의 y축은 위쪽이 +1 이므로, 사진 기준 '아래로'는 -y
            val centerX = if (panVertical) 0f else offset * (1f - halfW)
            val centerY = if (panVertical) -offset * (1f - halfH) else 0f

            val matrix = Matrix()
            matrix.postTranslate(-centerX, -centerY)
            matrix.postScale(1f / halfW, 1f / halfH)
            return matrix
        }

        private fun offsetAt(timeUs: Long): Float {
            if (keyframes.isEmpty()) return 0f
            if (timeUs <= keyframes.first().timeUs) return keyframes.first().offset
            if (timeUs >= keyframes.last().timeUs) return keyframes.last().offset
            for (i in 1 until keyframes.size) {
                val a = keyframes[i - 1]
                val b = keyframes[i]
                if (timeUs <= b.timeUs) {
                    val span = (b.timeUs - a.timeUs).toFloat()
                    if (span <= 0f) return b.offset
                    val t = (timeUs - a.timeUs) / span
                    return a.offset + (b.offset - a.offset) * t
                }
            }
            return keyframes.last().offset
        }
    }

    private var transformer: Transformer? = null
    private var progressPoller: Runnable? = null

    /** 반드시 메인 스레드에서 호출 */
    fun crop(
        context: Context,
        input: File,
        output: File,
        targetAspect: Float,
        keyframes: List<Keyframe>,
        callback: Callback
    ) {
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val effect = PanningCrop(targetAspect, keyframes)

        val item = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(input)))
            .setEffects(Effects(emptyList(), listOf(effect)))
            .build()

        val t = Transformer.Builder(context)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    stopPolling(handler)
                    transformer = null
                    callback.onDone(output)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    stopPolling(handler)
                    transformer = null
                    callback.onFailed(exportException.message ?: "export error")
                }
            })
            .build()

        transformer = t
        try {
            t.start(item, output.absolutePath)
        } catch (e: Exception) {
            transformer = null
            callback.onFailed(e.message ?: "start failed")
            return
        }

        val holder = ProgressHolder()
        val poll = object : Runnable {
            override fun run() {
                val current = transformer ?: return
                try {
                    current.getProgress(holder)
                    callback.onProgress(holder.progress)
                } catch (e: Exception) {
                    // 진행률은 참고용이므로 실패해도 무시
                }
                handler.postDelayed(this, 500L)
            }
        }
        progressPoller = poll
        handler.postDelayed(poll, 500L)
    }

    fun cancel() {
        try { transformer?.cancel() } catch (e: Exception) { /* 무시 */ }
        transformer = null
    }

    fun isBusy() = transformer != null

    private fun stopPolling(handler: android.os.Handler) {
        progressPoller?.let { handler.removeCallbacks(it) }
        progressPoller = null
    }

    // ---------- 갤러리에 저장 ----------

    /** 파일을 갤러리(동영상 > DualShot)로 옮긴다 */
    fun saveToGallery(context: Context, source: File, displayName: String): Uri? {
        return saveVideoStream(context, displayName) { out ->
            FileInputStream(source).use { input -> input.copyTo(out) }
        }
    }

    private fun saveVideoStream(context: Context, name: String, write: (OutputStream) -> Unit): Uri? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/" + FOLDER)
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            try {
                resolver.openOutputStream(uri)?.use { write(it) }
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                uri
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                null
            }
        } else {
            @Suppress("DEPRECATION")
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                FOLDER
            )
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, name)
            try {
                FileOutputStream(file).use { write(it) }
                MediaScannerConnection.scanFile(
                    context, arrayOf(file.absolutePath), arrayOf("video/mp4"), null
                )
                Uri.fromFile(file)
            } catch (e: Exception) {
                null
            }
        }
    }
}
