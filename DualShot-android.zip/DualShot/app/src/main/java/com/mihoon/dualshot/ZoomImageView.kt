package com.mihoon.dualshot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.RectF
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatImageView
import kotlin.math.max
import kotlin.math.min

/**
 * 핀치줌·드래그·더블탭 확대가 되는 이미지 뷰.
 */
class ZoomImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : AppCompatImageView(context, attrs, defStyleAttr) {

    private val minScale = 1f
    private val maxScale = 8f
    private var scale = 1f            // 화면에 맞춘 상태를 1로 본 배율
    private val current = Matrix()
    private val fitMatrix = Matrix()
    private var fitScale = 1f

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            zoomBy(d.scaleFactor, d.focusX, d.focusY)
            return true
        }
    })

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (scale > 1.01f) {
                current.postTranslate(-dx, -dy)
                fixBounds()
                imageMatrix = current
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (scale > 1.01f) resetToFit() else zoomBy(2.5f / scale, e.x, e.y)
            return true
        }

        override fun onDown(e: MotionEvent): Boolean = true
    })

    init {
        scaleType = ScaleType.MATRIX
    }

    override fun setImageBitmap(bm: Bitmap?) {
        super.setImageBitmap(bm)
        resetToFit()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        resetToFit()
    }

    private fun resetToFit() {
        val d = drawable ?: return
        val vw = width.toFloat()
        val vh = height.toFloat()
        if (vw == 0f || vh == 0f) return
        val dw = d.intrinsicWidth.toFloat()
        val dh = d.intrinsicHeight.toFloat()
        if (dw <= 0f || dh <= 0f) return

        fitScale = min(vw / dw, vh / dh)
        fitMatrix.reset()
        fitMatrix.postScale(fitScale, fitScale)
        fitMatrix.postTranslate((vw - dw * fitScale) / 2f, (vh - dh * fitScale) / 2f)

        current.set(fitMatrix)
        scale = 1f
        imageMatrix = current
    }

    private fun zoomBy(factor: Float, fx: Float, fy: Float) {
        val target = (scale * factor).coerceIn(minScale, maxScale)
        val real = target / scale
        if (real == 1f) return
        current.postScale(real, real, fx, fy)
        scale = target
        fixBounds()
        imageMatrix = current
    }

    /** 이미지가 화면보다 작으면 가운데 정렬, 크면 빈 공간이 생기지 않도록 이동 범위를 제한 */
    private fun fixBounds() {
        val d = drawable ?: return
        val rect = RectF(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat())
        current.mapRect(rect)
        val vw = width.toFloat()
        val vh = height.toFloat()

        var dx = 0f
        var dy = 0f
        if (rect.width() <= vw) {
            dx = (vw - rect.width()) / 2f - rect.left
        } else {
            if (rect.left > 0) dx = -rect.left
            if (rect.right < vw) dx = vw - rect.right
        }
        if (rect.height() <= vh) {
            dy = (vh - rect.height()) / 2f - rect.top
        } else {
            if (rect.top > 0) dy = -rect.top
            if (rect.bottom < vh) dy = vh - rect.bottom
        }
        current.postTranslate(dx, dy)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)
        if (event.actionMasked == MotionEvent.ACTION_UP) performClick()
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    @Suppress("unused")
    fun currentScale() = max(scale, minScale)
}
