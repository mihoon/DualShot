package com.mihoon.dualshot

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.View
import android.view.ViewConfiguration
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionFilter
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import androidx.media3.common.util.UnstableApi
import com.mihoon.dualshot.databinding.ActivityMainBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs

@UnstableApi
class MainActivity : AppCompatActivity() {

    private companion object {
        const val PREFS = "dualshot"
        const val KEY_WIDE = "wide_mode"
        const val KEY_ORIGINAL = "save_original"
        const val KEY_QUALITY = "quality_mode"
        const val KEY_OFFSET = "landscape_offset"
        const val KEY_HINT_SHOWN = "drag_hint_shown"
        const val KEY_VIDEO_QUALITY = "video_quality"
        const val KEY_VIDEO_HINT_SHOWN = "video_hint_shown"
        const val KEY_VIDEO_MODE = "video_mode"
        const val KEY_VIDEO_OFFSET = "video_crop_offset"
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: SharedPreferences

    /** 카메라 콜백 전용 (여기서는 오래 걸리는 일을 하지 않는다) */
    private lateinit var cameraExecutor: ExecutorService

    /** 자르기·저장 등 무거운 작업 전용 */
    private lateinit var processExecutor: ExecutorService

    private lateinit var orientationListener: OrientationEventListener

    private var cameraProvider: ProcessCameraProvider? = null
    private var extensionsManager: ExtensionsManager? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var camera: Camera? = null

    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var deviceRotation = Surface.ROTATION_0
    private var wideMode = true          // 사진: 9:16 / 16:9
    private var saveOriginal = false
    private var videoMode = false

    /** 사진: 가로 사진의 세로 위치 (-1 위 … 0 가운데 … +1 아래) */
    private var photoOffset = 0f

    /** 동영상: 세로 영상의 좌우 위치 (-1 왼쪽 … 0 가운데 … +1 오른쪽) */
    private var videoOffset = 0f

    private var pending = 0

    // 동영상
    private var recording: Recording? = null
    private var recordFile: File? = null
    private var recordStartMs = 0L
    private val keyframes = ArrayList<VideoCropper.Keyframe>()
    private val videoQualities = listOf(Quality.HD, Quality.FHD, Quality.UHD)
    private var videoQualityIndex = 1     // 기본 FHD

    /** 화질 보정 모드 (사진 전용) */
    private val qualityModes = listOf(
        ExtensionMode.AUTO, ExtensionMode.HDR, ExtensionMode.NIGHT, ExtensionMode.NONE
    )
    private var qualityIndex = 0

    private var lastPortraitUri: Uri? = null
    private var lastLandscapeUri: Uri? = null

    private val requiredPermissions: Array<String>
        get() = if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P)
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else
            arrayOf(Manifest.permission.CAMERA)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result[Manifest.permission.CAMERA] == true) {
                startCamera()
                refreshThumbs()
            } else {
                Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show()
                finish()
            }
        }

    private val audioPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) {
                Toast.makeText(this, R.string.video_permission_denied, Toast.LENGTH_LONG).show()
            }
        }

    private val reviewLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            refreshThumbs()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 동영상은 가로로 촬영하므로 화면 방향을 모드에 맞춘다
        videoMode = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_VIDEO_MODE, false)
        requestedOrientation = if (videoMode)
            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        else
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        cameraExecutor = Executors.newSingleThreadExecutor()
        processExecutor = Executors.newFixedThreadPool(2)

        restoreSettings()

        binding.shutterButton.setOnClickListener {
            if (videoMode) toggleRecording() else takeDualShot()
        }
        binding.flipButton.setOnClickListener { flipCamera() }
        binding.ratioButton.setOnClickListener {
            if (videoMode) cycleVideoQuality() else toggleRatio()
        }
        binding.qualityButton.setOnClickListener { cycleQuality() }
        binding.menuButton.setOnClickListener { showMenu() }
        binding.photoModeButton.setOnClickListener { setVideoMode(false) }
        binding.videoModeButton.setOnClickListener { setVideoMode(true) }
        binding.thumbPortrait.setOnClickListener { onThumbTapped(lastPortraitUri) }
        binding.thumbLandscape.setOnClickListener { onThumbTapped(lastLandscapeUri) }

        applyModeUi()
        setupPreviewGestures()

        // 화면은 세로로 고정하되, 폰을 눕혀 찍어도 사진이 바로 서도록 물리 회전을 추적한다
        orientationListener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == OrientationEventListener.ORIENTATION_UNKNOWN) return
                val rotation = when (orientation) {
                    in 45..134 -> Surface.ROTATION_270
                    in 135..224 -> Surface.ROTATION_180
                    in 225..314 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }
                if (rotation != deviceRotation) {
                    deviceRotation = rotation
                    imageCapture?.targetRotation = rotation
                    if (recording == null) videoCapture?.targetRotation = rotation
                    binding.guideOverlay.deviceRotation = rotation
                }
            }
        }

        if (hasPermissions()) {
            startCamera()
            refreshThumbs()
            maybeShowDragHint()
        } else {
            permissionLauncher.launch(requiredPermissions)
        }
    }

    private fun restoreSettings() {
        wideMode = prefs.getBoolean(KEY_WIDE, true)
        saveOriginal = prefs.getBoolean(KEY_ORIGINAL, false)
        photoOffset = prefs.getFloat(KEY_OFFSET, 0f).coerceIn(-1f, 1f)
        videoOffset = prefs.getFloat(KEY_VIDEO_OFFSET, 0f).coerceIn(-1f, 1f)
        videoQualityIndex = prefs.getInt(KEY_VIDEO_QUALITY, 1).coerceIn(0, videoQualities.size - 1)

        binding.guideOverlay.wideMode = wideMode
        binding.guideOverlay.videoMode = videoMode
        binding.guideOverlay.cropOffset = currentOffset()
    }

    private fun maybeShowDragHint() {
        if (prefs.getBoolean(KEY_HINT_SHOWN, false)) return
        prefs.edit().putBoolean(KEY_HINT_SHOWN, true).apply()
        binding.root.postDelayed({
            if (!isFinishing) Toast.makeText(this, R.string.drag_hint, Toast.LENGTH_LONG).show()
        }, 1200L)
    }

    override fun onResume() {
        super.onResume()
        if (orientationListener.canDetectOrientation()) orientationListener.enable()
    }

    override fun onPause() {
        orientationListener.disable()
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        recording?.stop()
        recording = null
        VideoCropper.cancel()
        cameraExecutor.shutdown()
        processExecutor.shutdown()
    }

    private fun hasPermissions() = requiredPermissions.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun hasAudioPermission() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    // ---------- 사진 / 동영상 모드 ----------

    private fun setVideoMode(video: Boolean) {
        if (videoMode == video) return
        if (recording != null) return

        prefs.edit().putBoolean(KEY_VIDEO_MODE, video).apply()
        if (video && !hasAudioPermission()) {
            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        // 동영상은 가로, 사진은 세로. 방향이 바뀌면 화면이 다시 만들어지며 적용된다.
        val wanted = if (video)
            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        else
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        val alreadyRight =
            (video && resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) ||
                (!video && resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_PORTRAIT)

        requestedOrientation = wanted
        if (!alreadyRight) return   // 다시 만들어질 때 적용된다

        videoMode = video
        binding.guideOverlay.videoMode = video
        binding.guideOverlay.cropOffset = currentOffset()
        applyModeUi()
        if (video) maybeShowVideoHint()
        binding.thumbPortrait.setImageDrawable(null)
        binding.thumbLandscape.setImageDrawable(null)
        lastPortraitUri = null
        lastLandscapeUri = null
        refreshThumbs()
        bindUseCases()
    }

    private fun maybeShowVideoHint() {
        if (prefs.getBoolean(KEY_VIDEO_HINT_SHOWN, false)) return
        prefs.edit().putBoolean(KEY_VIDEO_HINT_SHOWN, true).apply()
        Toast.makeText(this, R.string.video_hint, Toast.LENGTH_LONG).show()
    }

    private fun applyModeUi() {
        binding.photoModeButton.setTextColor(if (videoMode) 0xFFAAAAAA.toInt() else 0xFFFFFFFF.toInt())
        binding.videoModeButton.setTextColor(if (videoMode) 0xFFFFFFFF.toInt() else 0xFFAAAAAA.toInt())
        binding.qualityButton.visibility = if (videoMode) View.GONE else View.VISIBLE
        binding.shutterButton.setBackgroundResource(
            if (videoMode) R.drawable.record_button else R.drawable.shutter_button
        )
        binding.timerText.visibility = View.GONE

        val lp = binding.previewView.layoutParams as ConstraintLayout.LayoutParams
        lp.dimensionRatio = if (videoMode) "16:9" else "3:4"
        binding.previewView.layoutParams = lp

        updateRatioButton()
        updateQualityButton()
    }

    // ---------- 설정 메뉴 ----------

    private fun showMenu() {
        val originalState = if (saveOriginal) "ON" else "OFF"
        val items = arrayOf(
            getString(R.string.menu_language),
            getString(R.string.menu_reset_landscape),
            getString(R.string.menu_save_original) + "  ($originalState)",
            getString(R.string.menu_video_quality) + "  (" + videoQualityName() + ")"
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.menu)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showLanguageDialog()
                    1 -> {
                        setCurrentOffset(0f)
                        persistOffset()
                        Toast.makeText(this, R.string.landscape_reset, Toast.LENGTH_SHORT).show()
                    }
                    2 -> {
                        saveOriginal = !saveOriginal
                        prefs.edit().putBoolean(KEY_ORIGINAL, saveOriginal).apply()
                        Toast.makeText(
                            this,
                            getString(R.string.menu_save_original) + ": " + (if (saveOriginal) "ON" else "OFF"),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    3 -> showVideoQualityDialog()
                }
            }
            .show()
    }

    private fun showLanguageDialog() {
        val tags = arrayOf("", "ko", "en")
        val names = arrayOf(getString(R.string.lang_system), "한국어", "English")
        val current = AppCompatDelegate.getApplicationLocales().toLanguageTags()
        val checked = when {
            current.startsWith("ko") -> 1
            current.startsWith("en") -> 2
            else -> 0
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.menu_language)
            .setSingleChoiceItems(names, checked) { dialog, which ->
                dialog.dismiss()
                val locales =
                    if (tags[which].isEmpty()) LocaleListCompat.getEmptyLocaleList()
                    else LocaleListCompat.forLanguageTags(tags[which])
                AppCompatDelegate.setApplicationLocales(locales)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun videoQualityName() = when (videoQualityIndex) {
        0 -> "HD"
        2 -> "4K"
        else -> "FHD"
    }

    private fun showVideoQualityDialog() {
        val names = arrayOf("HD (720p)", "FHD (1080p)", "4K (2160p)")
        AlertDialog.Builder(this)
            .setTitle(R.string.menu_video_quality)
            .setSingleChoiceItems(names, videoQualityIndex) { dialog, which ->
                dialog.dismiss()
                videoQualityIndex = which
                prefs.edit().putInt(KEY_VIDEO_QUALITY, which).apply()
                updateRatioButton()
                if (videoMode) bindUseCases()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ---------- 카메라 ----------

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = try {
                providerFuture.get()
            } catch (e: Exception) {
                Toast.makeText(this, getString(R.string.camera_error, e.message ?: ""), Toast.LENGTH_LONG).show()
                return@addListener
            }
            cameraProvider = provider

            if (extensionsManager != null) {
                bindUseCases()
                return@addListener
            }
            val extFuture = ExtensionsManager.getInstanceAsync(this, provider)
            extFuture.addListener({
                extensionsManager = try { extFuture.get() } catch (e: Exception) { null }
                qualityIndex = restoredQualityIndex()
                updateQualityButton()
                bindUseCases()
            }, ContextCompat.getMainExecutor(this))
        }, ContextCompat.getMainExecutor(this))
    }

    private fun baseSelector() = CameraSelector.Builder().requireLensFacing(lensFacing).build()

    private fun isQualityAvailable(mode: Int): Boolean {
        if (mode == ExtensionMode.NONE) return true
        val manager = extensionsManager ?: return false
        return try {
            manager.isExtensionAvailable(baseSelector(), mode)
        } catch (e: Exception) {
            false
        }
    }

    private fun firstAvailableQuality(): Int {
        qualityModes.forEachIndexed { i, mode -> if (isQualityAvailable(mode)) return i }
        return qualityModes.indexOf(ExtensionMode.NONE).coerceAtLeast(0)
    }

    private fun restoredQualityIndex(): Int {
        val saved = prefs.getInt(KEY_QUALITY, Int.MIN_VALUE)
        val at = qualityModes.indexOf(saved)
        return if (at >= 0 && isQualityAvailable(saved)) at else firstAvailableQuality()
    }

    private fun bindUseCases() {
        val provider = cameraProvider ?: return
        if (recording != null) return

        try {
            camera?.cameraInfo?.zoomState?.removeObservers(this)
            provider.unbindAll()
            val cam = if (videoMode) bindVideo(provider) else bindPhoto(provider)
            camera = cam
            cam.cameraInfo.zoomState.observe(this) { state ->
                binding.zoomText.text = String.format(Locale.US, "%.1fx", state.zoomRatio)
            }
        } catch (e: Exception) {
            // 보정 모드로 묶기에 실패하면 보정 없이 다시 시도
            val mode = qualityModes.getOrElse(qualityIndex) { ExtensionMode.NONE }
            if (!videoMode && mode != ExtensionMode.NONE) {
                qualityIndex = qualityModes.indexOf(ExtensionMode.NONE).coerceAtLeast(0)
                updateQualityButton()
                bindUseCases()
            } else {
                Toast.makeText(this, getString(R.string.camera_error, e.message ?: ""), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun bindPhoto(provider: ProcessCameraProvider): Camera {
        // 센서 전체(4:3) 중에서 화소 결합(비닝) 해상도를 우선 고른다.
        // 최대 해상도 모드는 화소가 작아져 어두운 곳에서 노이즈가 크게 늘기 때문에,
        // 기본 카메라 앱과 비슷하게 1600만 화소 이하 중 가장 큰 것을 쓴다.
        val binnedFirst = ResolutionFilter { sizes, _ ->
            val limit = 16_000_000L
            val sorted = sizes.sortedByDescending { it.width.toLong() * it.height }
            val within = sorted.filter { it.width.toLong() * it.height <= limit }
            val above = sorted.filter { it.width.toLong() * it.height > limit }
            (within + above)
        }

        val captureSelector = ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
            .setResolutionFilter(binnedFirst)
            .build()

        val preview = Preview.Builder()
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                    .build()
            )
            .build()
            .also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }

        val capture = ImageCapture.Builder()
            .setResolutionSelector(captureSelector)
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setFlashMode(ImageCapture.FLASH_MODE_OFF)
            .setTargetRotation(deviceRotation)
            .build()

        val mode = qualityModes.getOrElse(qualityIndex) { ExtensionMode.NONE }
        val selector = if (mode != ExtensionMode.NONE && isQualityAvailable(mode)) {
            extensionsManager!!.getExtensionEnabledCameraSelector(baseSelector(), mode)
        } else baseSelector()

        val cam = provider.bindToLifecycle(this, selector, preview, capture)
        imageCapture = capture
        videoCapture = null
        return cam
    }

    private fun bindVideo(provider: ProcessCameraProvider): Camera {
        val quality = videoQualities[videoQualityIndex]
        val recorder = Recorder.Builder()
            .setQualitySelector(
                QualitySelector.from(quality, FallbackStrategy.lowerQualityOrHigherThan(Quality.HD))
            )
            .build()
        val vc = VideoCapture.withOutput(recorder)
        // 폰을 든 방향 그대로 녹화한다 (동영상 모드에서는 화면이 가로로 고정되므로 가로 영상이 된다)
        vc.targetRotation = deviceRotation

        val preview = Preview.Builder()
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
                    .build()
            )
            .build()
            .also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }

        val cam = provider.bindToLifecycle(this, baseSelector(), preview, vc)
        videoCapture = vc
        imageCapture = null
        return cam
    }

    /**
     * 미리보기 위 손가락 조작
     * - 두 손가락 벌리기 = 확대/축소
     * - 청록색 띠를 위아래로 끌기 = 가로 사진(영상) 위치 조절 (녹화 중에도 가능)
     * - 한 번 탭 = 초점, 띠를 두 번 탭 = 위치 가운데로
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun setupPreviewGestures() {
        val slop = ViewConfiguration.get(this).scaledTouchSlop

        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val cam = camera ?: return true
                val state = cam.cameraInfo.zoomState.value ?: return true
                val target = (state.zoomRatio * detector.scaleFactor)
                    .coerceIn(state.minZoomRatio, state.maxZoomRatio)
                cam.cameraControl.setZoomRatio(target)
                return true
            }
        })

        val tapDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val cam = camera ?: return true
                val point = binding.previewView.meteringPointFactory.createPoint(e.x, e.y)
                cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(point).build())
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (binding.guideOverlay.isInsideMovableBand(e.x, e.y)) {
                    setCurrentOffset(0f)
                    persistOffset()
                    Toast.makeText(this@MainActivity, R.string.landscape_reset, Toast.LENGTH_SHORT).show()
                    return true
                }
                return false
            }
        })

        var downX = 0f
        var downY = 0f
        var startOffset = 0f
        var inBand = false
        var dragging = false

        binding.guideOverlay.setOnTouchListener { _, event ->
            scaleDetector.onTouchEvent(event)

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    downY = event.y
                    startOffset = currentOffset()
                    inBand = binding.guideOverlay.isInsideMovableBand(event.x, event.y)
                    dragging = false
                }

                MotionEvent.ACTION_MOVE -> {
                    if (inBand && !scaleDetector.isInProgress && event.pointerCount == 1) {
                        val dx = event.x - downX
                        val dy = event.y - downY
                        if (!dragging) {
                            val vertical = binding.guideOverlay.isDragAxisVertical()
                            val along = if (vertical) dy else dx
                            val across = if (vertical) dx else dy
                            if (abs(along) > slop && abs(along) > abs(across)) dragging = true
                        }
                        if (dragging) {
                            setCurrentOffset(binding.guideOverlay.offsetAfterDrag(startOffset, dx, dy))
                        }
                    }
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        persistOffset()
                        dragging = false
                        inBand = false
                        return@setOnTouchListener true
                    }
                    inBand = false
                }
            }

            if (!dragging) tapDetector.onTouchEvent(event)
            true
        }

        binding.zoomText.setOnClickListener { camera?.cameraControl?.setZoomRatio(1f) }
    }

    private fun currentOffset() = if (videoMode) videoOffset else photoOffset

    private fun setCurrentOffset(value: Float) {
        val v = value.coerceIn(-1f, 1f)
        if (videoMode) videoOffset = v else photoOffset = v
        binding.guideOverlay.cropOffset = v
        // 녹화 중이면 움직임을 기록해 두었다가 세로 영상에 그대로 반영한다
        if (recording != null) {
            val timeUs = (SystemClock.elapsedRealtime() - recordStartMs) * 1000L
            keyframes.add(VideoCropper.Keyframe(timeUs, v))
        }
    }

    private fun persistOffset() {
        prefs.edit()
            .putFloat(if (videoMode) KEY_VIDEO_OFFSET else KEY_OFFSET, currentOffset())
            .apply()
    }

    private fun flipCamera() {
        if (recording != null) return
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        if (!isQualityAvailable(qualityModes.getOrElse(qualityIndex) { ExtensionMode.NONE })) {
            qualityIndex = firstAvailableQuality()
            updateQualityButton()
        }
        bindUseCases()
    }

    private fun toggleRatio() {
        wideMode = !wideMode
        binding.guideOverlay.wideMode = wideMode
        prefs.edit().putBoolean(KEY_WIDE, wideMode).apply()
        updateRatioButton()
    }

    private fun cycleVideoQuality() {
        if (recording != null) return
        videoQualityIndex = (videoQualityIndex + 1) % videoQualities.size
        prefs.edit().putInt(KEY_VIDEO_QUALITY, videoQualityIndex).apply()
        updateRatioButton()
        bindUseCases()
    }

    private fun updateRatioButton() {
        binding.ratioButton.text =
            if (videoMode) videoQualityName()
            else if (wideMode) "9:16 · 16:9" else "3:4 · 4:3"
    }

    private fun cycleQuality() {
        val start = qualityIndex
        var next = qualityIndex
        for (i in 1..qualityModes.size) {
            next = (start + i) % qualityModes.size
            if (isQualityAvailable(qualityModes[next])) break
        }
        if (next == qualityIndex) {
            Toast.makeText(this, R.string.quality_unavailable, Toast.LENGTH_SHORT).show()
            return
        }
        qualityIndex = next
        prefs.edit().putInt(KEY_QUALITY, qualityModes[next]).apply()
        updateQualityButton()
        bindUseCases()
    }

    private fun updateQualityButton() {
        binding.qualityButton.text = when (qualityModes.getOrElse(qualityIndex) { ExtensionMode.NONE }) {
            ExtensionMode.AUTO -> getString(R.string.quality_auto)
            ExtensionMode.HDR -> getString(R.string.quality_hdr)
            ExtensionMode.NIGHT -> getString(R.string.quality_night)
            else -> getString(R.string.quality_none)
        }
    }

    // ---------- 동영상 ----------

    @SuppressLint("MissingPermission")
    private fun toggleRecording() {
        val vc = videoCapture ?: return

        val active = recording
        if (active != null) {
            active.stop()
            return
        }
        if (VideoCropper.isBusy()) {
            Toast.makeText(this, R.string.video_busy, Toast.LENGTH_SHORT).show()
            return
        }

        val file = File(cacheDir, "rec_${System.currentTimeMillis()}.mp4")
        recordFile = file
        keyframes.clear()
        keyframes.add(VideoCropper.Keyframe(0L, videoOffset))
        recordStartMs = SystemClock.elapsedRealtime()

        var prepared = vc.output.prepareRecording(this, FileOutputOptions.Builder(file).build())
        if (hasAudioPermission()) prepared = prepared.withAudioEnabled()

        recording = try {
            prepared.start(ContextCompat.getMainExecutor(this)) { event -> onRecordEvent(event) }
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.recording_failed, e.message ?: ""), Toast.LENGTH_LONG).show()
            file.delete()
            recordFile = null
            null
        }
        if (recording != null) setRecordingUi(true)
    }

    private fun onRecordEvent(event: VideoRecordEvent) {
        when (event) {
            is VideoRecordEvent.Status -> {
                val seconds = event.recordingStats.recordedDurationNanos / 1_000_000_000L
                binding.timerText.text =
                    String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)
            }

            is VideoRecordEvent.Finalize -> {
                val file = recordFile
                recordFile = null
                recording = null
                setRecordingUi(false)
                if (event.hasError()) {
                    Toast.makeText(
                        this,
                        getString(R.string.recording_failed, event.cause?.message ?: "code ${event.error}"),
                        Toast.LENGTH_LONG
                    ).show()
                    file?.delete()
                } else if (file != null && file.exists()) {
                    onRecordingSaved(file)
                }
            }
        }
    }

    private fun setRecordingUi(active: Boolean) {
        requestedOrientation = if (active)
            ActivityInfo.SCREEN_ORIENTATION_LOCKED
        else if (videoMode)
            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        else
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        binding.timerText.visibility = if (active) View.VISIBLE else View.GONE
        if (active) binding.timerText.text = "00:00"
        binding.shutterButton.setBackgroundResource(
            if (active) R.drawable.stop_button else R.drawable.record_button
        )
        binding.photoModeButton.isEnabled = !active
        binding.videoModeButton.isEnabled = !active
        binding.flipButton.isEnabled = !active
        binding.ratioButton.isEnabled = !active
        binding.menuButton.isEnabled = !active
    }

    /** 녹화본 자체가 '가로 영상'이다. 저장한 뒤 세로 영상을 만들기 시작한다. */
    private fun onRecordingSaved(file: File) {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val snapshot = ArrayList(keyframes)

        processExecutor.execute {
            val uri = VideoCropper.saveToGallery(this, file, "DualShot_${stamp}_H.mp4")
            runOnUiThread {
                if (uri == null) {
                    Toast.makeText(this, getString(R.string.save_failed, "video"), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, R.string.video_saved_portrait, Toast.LENGTH_SHORT).show()
                    refreshThumbs()
                }
                startLandscapeExport(file, stamp, snapshot)
            }
        }
    }

    private fun startLandscapeExport(
        input: File,
        stamp: String,
        frames: List<VideoCropper.Keyframe>
    ) {
        val output = File(cacheDir, "land_$stamp.mp4")
        binding.exportText.visibility = View.VISIBLE
        binding.exportText.text = getString(R.string.exporting, 0)
        Toast.makeText(this, R.string.keep_open_hint, Toast.LENGTH_SHORT).show()

        VideoCropper.crop(this, input, output, 9f / 16f, frames, object : VideoCropper.Callback {
            override fun onProgress(percent: Int) {
                binding.exportText.text = getString(R.string.exporting, percent.coerceIn(0, 100))
            }

            override fun onDone(result: File) {
                processExecutor.execute {
                    val uri = VideoCropper.saveToGallery(this@MainActivity, result, "DualShot_${stamp}_V.mp4")
                    result.delete()
                    input.delete()
                    runOnUiThread {
                        binding.exportText.visibility = View.GONE
                        val message = if (uri != null) getString(R.string.video_done)
                        else getString(R.string.video_export_failed, "save")
                        Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
                        refreshThumbs()
                    }
                }
            }

            override fun onFailed(message: String) {
                binding.exportText.visibility = View.GONE
                input.delete()
                output.delete()
                Toast.makeText(
                    this@MainActivity,
                    getString(R.string.video_export_failed, message),
                    Toast.LENGTH_LONG
                ).show()
            }
        })
    }

    // ---------- 사진 촬영 ----------

    private fun takeDualShot() {
        val capture = imageCapture ?: return
        val useWideMode = wideMode
        val alsoOriginal = saveOriginal
        val offset = photoOffset
        pendingUp()

        capture.takePicture(cameraExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val bytes = try {
                    DualShotProcessor.readBytes(image)
                } catch (e: Exception) {
                    runOnUiThread { onFailed(e.message ?: "read error") }
                    image.close()
                    return
                }
                val rotation = image.imageInfo.rotationDegrees
                image.close()
                runOnUiThread { flashScreen() }

                processExecutor.execute {
                    try {
                        val result = DualShotProcessor.process(
                            this@MainActivity, bytes, rotation, useWideMode, alsoOriginal, offset
                        )
                        runOnUiThread { onSaved(result) }
                    } catch (e: Exception) {
                        runOnUiThread { onFailed(e.message ?: "unknown") }
                    } catch (e: OutOfMemoryError) {
                        runOnUiThread { onFailed(getString(R.string.out_of_memory)) }
                    }
                }
            }

            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { onFailed(exception.message ?: "capture error") }
            }
        })
    }

    private fun onSaved(result: DualShotProcessor.Result) {
        result.portrait?.let { binding.thumbPortrait.setImageBitmap(it) }
        result.landscape?.let { binding.thumbLandscape.setImageBitmap(it) }
        result.portraitUri?.let { lastPortraitUri = it }
        result.landscapeUri?.let { lastLandscapeUri = it }

        if (result.portraitUri == null && result.landscapeUri == null) {
            onFailed(getString(R.string.save_none))
            return
        }
        pendingDown()
    }

    private fun onFailed(message: String) {
        Toast.makeText(this, getString(R.string.save_failed, message), Toast.LENGTH_LONG).show()
        pendingDown()
    }

    private fun pendingUp() {
        pending++
        binding.progress.visibility = View.VISIBLE
    }

    private fun pendingDown() {
        pending = (pending - 1).coerceAtLeast(0)
        if (pending == 0) binding.progress.visibility = View.GONE
    }

    private fun flashScreen() {
        val flash = binding.flashView
        flash.alpha = 0.75f
        flash.visibility = View.VISIBLE
        flash.animate().alpha(0f).setDuration(180L).withEndAction {
            flash.visibility = View.GONE
        }.start()
    }

    // ---------- 결과 보기 ----------

    private fun refreshThumbs() {
        val video = videoMode
        processExecutor.execute {
            val shots = if (video) ShotGallery.loadVideos(this) else ShotGallery.load(this)
            val p = ShotGallery.latestPortrait(shots)
            val l = ShotGallery.latestLandscape(shots)
            val pb = p?.let {
                if (video) ShotGallery.loadVideoThumb(this, it.uri, 256)
                else ShotGallery.loadScaled(this, it.uri, 256)
            }
            val lb = l?.let {
                if (video) ShotGallery.loadVideoThumb(this, it.uri, 256)
                else ShotGallery.loadScaled(this, it.uri, 256)
            }
            runOnUiThread {
                // 결과가 도착하는 사이에 모드가 바뀌었으면 버린다
                if (video != videoMode) return@runOnUiThread
                lastPortraitUri = p?.uri
                lastLandscapeUri = l?.uri
                if (pb != null) binding.thumbPortrait.setImageBitmap(pb)
                else binding.thumbPortrait.setImageDrawable(null)
                if (lb != null) binding.thumbLandscape.setImageBitmap(lb)
                else binding.thumbLandscape.setImageDrawable(null)
            }
        }
    }

    private fun onThumbTapped(startUri: Uri?) {
        if (videoMode) {
            openVideo(startUri)
            return
        }
        val intent = Intent(this, ReviewActivity::class.java)
        startUri?.let { intent.putExtra(ReviewActivity.EXTRA_START_URI, it.toString()) }
        reviewLauncher.launch(intent)
    }

    /** 동영상은 기기의 기본 재생기로 연다 */
    private fun openVideo(uri: Uri?) {
        if (uri == null) {
            processExecutor.execute {
                val latest = ShotGallery.latestVideo(this)
                runOnUiThread { playVideo(latest) }
            }
            return
        }
        playVideo(uri)
    }

    private fun playVideo(uri: Uri?) {
        if (uri == null) {
            Toast.makeText(this, R.string.no_videos, Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "video/mp4")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
        } catch (e: Exception) {
            Toast.makeText(this, R.string.no_videos, Toast.LENGTH_SHORT).show()
        }
    }
}
