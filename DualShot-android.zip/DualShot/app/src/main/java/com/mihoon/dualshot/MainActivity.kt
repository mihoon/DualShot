package com.mihoon.dualshot

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.OrientationEventListener
import android.view.Surface
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.mihoon.dualshot.databinding.ActivityMainBinding
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var orientationListener: OrientationEventListener

    private var imageCapture: ImageCapture? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var deviceRotation = Surface.ROTATION_0
    private var wideMode = true          // 9:16 / 16:9
    private var saveOriginal = false
    private var busy = false

    private val requiredPermissions: Array<String>
        get() = if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P)
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else
            arrayOf(Manifest.permission.CAMERA)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result[Manifest.permission.CAMERA] == true) {
                startCamera()
            } else {
                Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show()
                finish()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraExecutor = Executors.newSingleThreadExecutor()

        binding.shutterButton.setOnClickListener { takeDualShot() }
        binding.flipButton.setOnClickListener { flipCamera() }
        binding.ratioButton.setOnClickListener { toggleRatio() }
        binding.saveOriginalCheck.setOnCheckedChangeListener { _, checked -> saveOriginal = checked }

        updateRatioButton()

        // 화면은 세로로 고정하되, 폰을 눕혀 찍어도 사진이 바로 서도록 물리 회전을 추적한다
        orientationListener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == OrientationEventListener.ORIENTATION_UNKNOWN) return
                val rotation = when (orientation) {
                    in 45..134 -> Surface.ROTATION_270
                    in 135..224 -> Surface.ROTATION_180
                    in 225..314 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }
                if (rotation != deviceRotation) {
                    deviceRotation = rotation
                    imageCapture?.targetRotation = rotation
                    binding.guideOverlay.deviceRotation = rotation
                }
            }
        }

        if (hasPermissions()) startCamera() else permissionLauncher.launch(requiredPermissions)
    }

    override fun onResume() {
        super.onResume()
        if (orientationListener.canDetectOrientation()) orientationListener.enable()
    }

    override fun onPause() {
        orientationListener.disable()
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }

    private fun hasPermissions() = requiredPermissions.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()

            // 미리보기와 촬영 모두 센서 전체(4:3)를 쓰도록 맞춘다
            val resolutionSelector = ResolutionSelector.Builder()
                .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                .build()

            val preview = Preview.Builder()
                .setResolutionSelector(resolutionSelector)
                .build()
                .also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }

            val capture = ImageCapture.Builder()
                .setResolutionSelector(resolutionSelector)
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setTargetRotation(deviceRotation)
                .build()
            imageCapture = capture

            val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()

            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, preview, capture)
            } catch (e: Exception) {
                Toast.makeText(this, getString(R.string.camera_error, e.message ?: ""), Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun flipCamera() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        startCamera()
    }

    private fun toggleRatio() {
        wideMode = !wideMode
        binding.guideOverlay.wideMode = wideMode
        updateRatioButton()
    }

    private fun updateRatioButton() {
        binding.ratioButton.text = if (wideMode) "9:16 · 16:9" else "3:4 · 4:3"
    }

    private fun takeDualShot() {
        val capture = imageCapture ?: return
        if (busy) return
        busy = true
        binding.shutterButton.isEnabled = false
        binding.progress.visibility = android.view.View.VISIBLE

        capture.takePicture(cameraExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val result = DualShotProcessor.process(
                        this@MainActivity, image, wideMode, saveOriginal
                    )
                    runOnUiThread { onSaved(result) }
                } catch (e: Exception) {
                    runOnUiThread { onFailed(e.message ?: "unknown") }
                } finally {
                    image.close()
                }
            }

            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { onFailed(exception.message ?: "capture error") }
            }
        })
    }

    private fun onSaved(result: DualShotProcessor.Result) {
        binding.thumbPortrait.setImageBitmap(result.portrait)
        binding.thumbLandscape.setImageBitmap(result.landscape)
        val count = if (result.originalUri != null) 3 else 2
        Toast.makeText(this, getString(R.string.saved_toast, count), Toast.LENGTH_SHORT).show()
        resetShutter()
    }

    private fun onFailed(message: String) {
        Toast.makeText(this, getString(R.string.save_failed, message), Toast.LENGTH_LONG).show()
        resetShutter()
    }

    private fun resetShutter() {
        busy = false
        binding.shutterButton.isEnabled = true
        binding.progress.visibility = android.view.View.GONE
    }
}
