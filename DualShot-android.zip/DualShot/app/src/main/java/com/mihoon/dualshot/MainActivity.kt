package com.mihoon.dualshot

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Size
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.ScaleGestureDetector
import android.view.Surface
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionFilter
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.mihoon.dualshot.databinding.ActivityMainBinding
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var orientationListener: OrientationEventListener

    private var cameraProvider: ProcessCameraProvider? = null
    private var extensionsManager: ExtensionsManager? = null
    private var imageCapture: ImageCapture? = null
    private var camera: Camera? = null

    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var deviceRotation = Surface.ROTATION_0
    private var wideMode = true          // 9:16 / 16:9
    private var saveOriginal = false
    private var busy = false

    /** 화질 보정 모드: 제조사가 제공하는 다중 프레임 처리(HDR/야간 등) */
    private val qualityModes = listOf(
        ExtensionMode.AUTO, ExtensionMode.HDR, ExtensionMode.NIGHT, ExtensionMode.NONE
    )
    private var qualityIndex = 0

    /** 마지막 촬영 결과 (라벨, URI) — 썸네일을 눌러 전체화면으로 볼 때 사용 */
    private var lastShots = ArrayList<Pair<String, Uri>>()

    private val requiredPermissions: Array<String>
        get() = if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P)
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else
            arrayOf(Manifest.permission.CAMERA)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result[Manifest.permission.CAMERA] == true) {
                startCamera()
            } else {
                Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show()
                finish()
            }
        }

    private val reviewLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val deleted = result.data?.getStringArrayListExtra(ReviewActivity.RESULT_DELETED_URIS)
                ?: return@registerForActivityResult
            if (deleted.isEmpty()) return@registerForActivityResult
            lastShots.removeAll { it.second.toString() in deleted }
            if (lastShots.none { it.first == getString(R.string.label_portrait) })
                binding.thumbPortrait.setImageDrawable(null)
            if (lastShots.none { it.first == getString(R.string.label_landscape) })
                binding.thumbLandscape.setImageDrawable(null)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraExecutor = Executors.newSingleThreadExecutor()

        binding.shutterButton.setOnClickListener { takeDualShot() }
        binding.flipButton.setOnClickListener { flipCamera() }
        binding.ratioButton.setOnClickListener { toggleRatio() }
        binding.qualityButton.setOnClickListener { cycleQuality() }
        binding.saveOriginalCheck.setOnCheckedChangeListener { _, checked -> saveOriginal = checked }
        binding.thumbPortrait.setOnClickListener { openReview(getString(R.string.label_portrait)) }
        binding.thumbLandscape.setOnClickListener { openReview(getString(R.string.label_landscape)) }

        updateRatioButton()
        updateQualityButton()
        setupZoomAndFocus()

        // 화면은 세로로 고정하되, 폰을 눕혀 찍어도 사진이 바로 서도록 물리 회전을 추적한다
        orientationListener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == OrientationEventListener.ORIENTATION_UNKNOWN) return
                val rotation = when (orientation) {
                    in 45..134 -> Surface.ROTATION_270
                    in 135..224 -> Surface.ROTATION_180
                    in 225..314 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }
                if (rotation != deviceRotation) {
                    deviceRotation = rotation
                    imageCapture?.targetRotation = rotation
                    binding.guideOverlay.deviceRotation = rotation
                }
            }
        }

        if (hasPermissions()) startCamera() else permissionLauncher.launch(requiredPermissions)
    }

    override fun onResume() {
        super.onResume()
        if (orientationListener.canDetectOrientation()) orientationListener.enable()
    }

    override fun onPause() {
        orientationListener.disable()
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }

    private fun hasPermissions() = requiredPermissions.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    // ---------- 카메라 ----------

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = try {
                providerFuture.get()
            } catch (e: Exception) {
                Toast.makeText(this, getString(R.string.camera_error, e.message ?: ""), Toast.LENGTH_LONG).show()
                return@addListener
            }
            cameraProvider = provider

            if (extensionsManager != null) {
                bindUseCases()
                return@addListener
            }
            // 제조사 화질 보정(익스텐션) 사용 가능 여부 확인
            val extFuture = ExtensionsManager.getInstanceAsync(this, provider)
            extFuture.addListener({
                extensionsManager = try { extFuture.get() } catch (e: Exception) { null }
                // 이 기기에서 실제로 쓸 수 있는 모드로 시작점을 옮긴다
                qualityIndex = firstAvailableQuality()
                updateQualityButton()
                bindUseCases()
            }, ContextCompat.getMainExecutor(this))
        }, ContextCompat.getMainExecutor(this))
    }

    private fun baseSelector() = CameraSelector.Builder().requireLensFacing(lensFacing).build()

    private fun isQualityAvailable(mode: Int): Boolean {
        if (mode == ExtensionMode.NONE) return true
        val manager = extensionsManager ?: return false
        return try {
            manager.isExtensionAvailable(baseSelector(), mode)
        } catch (e: Exception) {
            false
        }
    }

    private fun firstAvailableQuality(): Int {
        qualityModes.forEachIndexed { i, mode -> if (isQualityAvailable(mode)) return i }
        return qualityModes.indexOf(ExtensionMode.NONE).coerceAtLeast(0)
    }

    private fun bindUseCases() {
        val provider = cameraProvider ?: return

        // 센서 전체(4:3) 중에서 화소 결합(비닝) 해상도를 우선 고른다.
        // 최대 해상도 모드는 화소가 작아져 어두운 곳에서 노이즈가 크게 늘기 때문에,
        // 기본 카메라 앱과 비슷하게 1600만 화소 이하 중 가장 큰 것을 쓴다.
        val binnedFirst = ResolutionFilter { sizes, _ ->
            val limit = 16_000_000L
            val sorted = sizes.sortedByDescending { it.width.toLong() * it.height }
            val within = sorted.filter { it.width.toLong() * it.height <= limit }
            val above = sorted.filter { it.width.toLong() * it.height > limit }
            (within + above)
        }

        val resolutionSelector = ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
            .setResolutionFilter(binnedFirst)
            .build()

        val preview = Preview.Builder()
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                    .build()
            )
            .build()
            .also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }

        val capture = ImageCapture.Builder()
            .setResolutionSelector(resolutionSelector)
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setFlashMode(ImageCapture.FLASH_MODE_OFF)
            .setTargetRotation(deviceRotation)
            .build()

        val mode = qualityModes.getOrElse(qualityIndex) { ExtensionMode.NONE }
        val selector = if (mode != ExtensionMode.NONE && isQualityAvailable(mode)) {
            try {
                extensionsManager!!.getExtensionEnabledCameraSelector(baseSelector(), mode)
            } catch (e: Exception) {
                baseSelector()
            }
        } else baseSelector()

        try {
            camera?.cameraInfo?.zoomState?.removeObservers(this)
            provider.unbindAll()
            val cam = provider.bindToLifecycle(this, selector, preview, capture)
            camera = cam
            imageCapture = capture
            cam.cameraInfo.zoomState.observe(this) { state ->
                binding.zoomText.text = String.format(Locale.US, "%.1fx", state.zoomRatio)
            }
        } catch (e: Exception) {
            // 보정 모드로 묶기에 실패하면 보정 없이 다시 시도
            if (mode != ExtensionMode.NONE) {
                qualityIndex = qualityModes.indexOf(ExtensionMode.NONE).coerceAtLeast(0)
                updateQualityButton()
                bindUseCases()
            } else {
                Toast.makeText(this, getString(R.string.camera_error, e.message ?: ""), Toast.LENGTH_LONG).show()
            }
        }
    }

    /** 미리보기 위에서 두 손가락 벌리기 = 줌, 한 번 탭 = 초점 맞추기, 배율 표시 탭 = 1x로 */
    @SuppressLint("ClickableViewAccessibility")
    private fun setupZoomAndFocus() {
        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val cam = camera ?: return true
                val state = cam.cameraInfo.zoomState.value ?: return true
                val target = (state.zoomRatio * detector.scaleFactor)
                    .coerceIn(state.minZoomRatio, state.maxZoomRatio)
                cam.cameraControl.setZoomRatio(target)
                return true
            }
        })
        val tapDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val cam = camera ?: return true
                val point = binding.previewView.meteringPointFactory.createPoint(e.x, e.y)
                cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(point).build())
                return true
            }
        })
        binding.guideOverlay.setOnTouchListener { _, event ->
            scaleDetector.onTouchEvent(event)
            if (!scaleDetector.isInProgress) tapDetector.onTouchEvent(event)
            true
        }
        binding.zoomText.setOnClickListener { camera?.cameraControl?.setZoomRatio(1f) }
    }

    private fun flipCamera() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        if (!isQualityAvailable(qualityModes.getOrElse(qualityIndex) { ExtensionMode.NONE })) {
            qualityIndex = firstAvailableQuality()
            updateQualityButton()
        }
        bindUseCases()
    }

    private fun toggleRatio() {
        wideMode = !wideMode
        binding.guideOverlay.wideMode = wideMode
        updateRatioButton()
    }

    private fun updateRatioButton() {
        binding.ratioButton.text = if (wideMode) "9:16 · 16:9" else "3:4 · 4:3"
    }

    /** 이 기기에서 쓸 수 있는 화질 보정 모드를 순서대로 돌아가며 선택 */
    private fun cycleQuality() {
        val start = qualityIndex
        var next = qualityIndex
        for (i in 1..qualityModes.size) {
            next = (start + i) % qualityModes.size
            if (isQualityAvailable(qualityModes[next])) break
        }
        if (next == qualityIndex) {
            Toast.makeText(this, R.string.quality_unavailable, Toast.LENGTH_SHORT).show()
            return
        }
        qualityIndex = next
        updateQualityButton()
        bindUseCases()
    }

    private fun updateQualityButton() {
        binding.qualityButton.text = when (qualityModes.getOrElse(qualityIndex) { ExtensionMode.NONE }) {
            ExtensionMode.AUTO -> getString(R.string.quality_auto)
            ExtensionMode.HDR -> getString(R.string.quality_hdr)
            ExtensionMode.NIGHT -> getString(R.string.quality_night)
            else -> getString(R.string.quality_none)
        }
    }

    // ---------- 촬영 ----------

    private fun takeDualShot() {
        val capture = imageCapture ?: return
        if (busy) return
        busy = true
        binding.shutterButton.isEnabled = false
        binding.progress.visibility = android.view.View.VISIBLE

        capture.takePicture(cameraExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val result = DualShotProcessor.process(
                        this@MainActivity, image, wideMode, saveOriginal
                    )
                    runOnUiThread { onSaved(result) }
                } catch (e: Exception) {
                    runOnUiThread { onFailed(e.message ?: "unknown") }
                } catch (e: OutOfMemoryError) {
                    runOnUiThread { onFailed("메모리 부족") }
                } finally {
                    image.close()
                }
            }

            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { onFailed(exception.message ?: "capture error") }
            }
        })
    }

    private fun onSaved(result: DualShotProcessor.Result) {
        binding.thumbPortrait.setImageBitmap(result.portrait)
        binding.thumbLandscape.setImageBitmap(result.landscape)

        lastShots = ArrayList()
        result.portraitUri?.let { lastShots.add(getString(R.string.label_portrait) to it) }
        result.landscapeUri?.let { lastShots.add(getString(R.string.label_landscape) to it) }
        result.originalUri?.let { lastShots.add(getString(R.string.label_original) to it) }

        if (lastShots.isEmpty()) {
            onFailed(getString(R.string.save_none))
            return
        }
        Toast.makeText(this, getString(R.string.saved_toast, lastShots.size), Toast.LENGTH_SHORT).show()
        resetShutter()
    }

    private fun onFailed(message: String) {
        Toast.makeText(this, getString(R.string.save_failed, message), Toast.LENGTH_LONG).show()
        resetShutter()
    }

    private fun openReview(startLabel: String) {
        if (lastShots.isEmpty()) return
        val start = lastShots.indexOfFirst { it.first == startLabel }.coerceAtLeast(0)
        val intent = Intent(this, ReviewActivity::class.java)
            .putStringArrayListExtra(ReviewActivity.EXTRA_URIS, ArrayList(lastShots.map { it.second.toString() }))
            .putStringArrayListExtra(ReviewActivity.EXTRA_LABELS, ArrayList(lastShots.map { it.first }))
            .putExtra(ReviewActivity.EXTRA_START, start)
        reviewLauncher.launch(intent)
    }

    private fun resetShutter() {
        busy = false
        binding.shutterButton.isEnabled = true
        binding.progress.visibility = android.view.View.GONE
    }
}
