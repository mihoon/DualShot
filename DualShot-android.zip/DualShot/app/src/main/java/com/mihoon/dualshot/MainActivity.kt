package com.mihoon.dualshot

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.View
import android.view.ViewConfiguration
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionFilter
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import com.mihoon.dualshot.databinding.ActivityMainBinding
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private companion object {
        const val PREFS = "dualshot"
        const val KEY_WIDE = "wide_mode"
        const val KEY_ORIGINAL = "save_original"
        const val KEY_QUALITY = "quality_mode"
        const val KEY_OFFSET = "landscape_offset"
        const val KEY_HINT_SHOWN = "drag_hint_shown"
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: SharedPreferences

    /** 카메라 콜백 전용 (여기서는 오래 걸리는 일을 하지 않는다) */
    private lateinit var cameraExecutor: ExecutorService

    /** 자르기·저장 등 무거운 작업 전용 */
    private lateinit var processExecutor: ExecutorService

    private lateinit var orientationListener: OrientationEventListener

    private var cameraProvider: ProcessCameraProvider? = null
    private var extensionsManager: ExtensionsManager? = null
    private var imageCapture: ImageCapture? = null
    private var camera: Camera? = null

    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var deviceRotation = Surface.ROTATION_0
    private var wideMode = true          // 9:16 / 16:9
    private var saveOriginal = false

    /** 가로 사진의 세로 위치 (-1 위 … 0 가운데 … +1 아래) */
    private var landscapeOffset = 0f

    /** 저장 대기 중인 촬영 수 (0보다 크면 진행 표시) */
    private var pending = 0

    /** 화질 보정 모드: 제조사가 제공하는 다중 프레임 처리(HDR/야간 등) */
    private val qualityModes = listOf(
        ExtensionMode.AUTO, ExtensionMode.HDR, ExtensionMode.NIGHT, ExtensionMode.NONE
    )
    private var qualityIndex = 0

    private var lastPortraitUri: Uri? = null
    private var lastLandscapeUri: Uri? = null

    private val requiredPermissions: Array<String>
        get() = if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P)
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else
            arrayOf(Manifest.permission.CAMERA)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result[Manifest.permission.CAMERA] == true) {
                startCamera()
                refreshThumbs()
            } else {
                Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show()
                finish()
            }
        }

    private val reviewLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            refreshThumbs()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        cameraExecutor = Executors.newSingleThreadExecutor()
        processExecutor = Executors.newFixedThreadPool(2)

        restoreSettings()

        binding.shutterButton.setOnClickListener { takeDualShot() }
        binding.flipButton.setOnClickListener { flipCamera() }
        binding.ratioButton.setOnClickListener { toggleRatio() }
        binding.qualityButton.setOnClickListener { cycleQuality() }
        binding.menuButton.setOnClickListener { showMenu() }
        binding.saveOriginalCheck.setOnCheckedChangeListener { _, checked ->
            saveOriginal = checked
            prefs.edit().putBoolean(KEY_ORIGINAL, checked).apply()
        }
        binding.thumbPortrait.setOnClickListener { openReview(lastPortraitUri) }
        binding.thumbLandscape.setOnClickListener { openReview(lastLandscapeUri) }

        updateRatioButton()
        updateQualityButton()
        setupPreviewGestures()

        // 화면은 세로로 고정하되, 폰을 눕혀 찍어도 사진이 바로 서도록 물리 회전을 추적한다
        orientationListener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == OrientationEventListener.ORIENTATION_UNKNOWN) return
                val rotation = when (orientation) {
                    in 45..134 -> Surface.ROTATION_270
                    in 135..224 -> Surface.ROTATION_180
                    in 225..314 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }
                if (rotation != deviceRotation) {
                    deviceRotation = rotation
                    imageCapture?.targetRotation = rotation
                    binding.guideOverlay.deviceRotation = rotation
                }
            }
        }

        if (hasPermissions()) {
            startCamera()
            refreshThumbs()
            maybeShowDragHint()
        } else {
            permissionLauncher.launch(requiredPermissions)
        }
    }

    private fun restoreSettings() {
        wideMode = prefs.getBoolean(KEY_WIDE, true)
        saveOriginal = prefs.getBoolean(KEY_ORIGINAL, false)
        landscapeOffset = prefs.getFloat(KEY_OFFSET, 0f).coerceIn(-1f, 1f)

        binding.saveOriginalCheck.isChecked = saveOriginal
        binding.guideOverlay.wideMode = wideMode
        binding.guideOverlay.landscapeOffset = landscapeOffset
    }

    private fun maybeShowDragHint() {
        if (prefs.getBoolean(KEY_HINT_SHOWN, false)) return
        prefs.edit().putBoolean(KEY_HINT_SHOWN, true).apply()
        binding.root.postDelayed({
            if (!isFinishing) Toast.makeText(this, R.string.drag_hint, Toast.LENGTH_LONG).show()
        }, 1200L)
    }

    override fun onResume() {
        super.onResume()
        if (orientationListener.canDetectOrientation()) orientationListener.enable()
    }

    override fun onPause() {
        orientationListener.disable()
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        processExecutor.shutdown()
    }

    private fun hasPermissions() = requiredPermissions.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    // ---------- 설정 메뉴 ----------

    private fun showMenu() {
        val items = arrayOf(
            getString(R.string.menu_language),
            getString(R.string.menu_reset_landscape)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.menu)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showLanguageDialog()
                    1 -> {
                        setLandscapeOffset(0f)
                        persistOffset()
                        Toast.makeText(this, R.string.landscape_reset, Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    private fun showLanguageDialog() {
        val tags = arrayOf("", "ko", "en")
        val names = arrayOf(getString(R.string.lang_system), "한국어", "English")
        val current = AppCompatDelegate.getApplicationLocales().toLanguageTags()
        val checked = when {
            current.startsWith("ko") -> 1
            current.startsWith("en") -> 2
            else -> 0
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.menu_language)
            .setSingleChoiceItems(names, checked) { dialog, which ->
                dialog.dismiss()
                val locales =
                    if (tags[which].isEmpty()) LocaleListCompat.getEmptyLocaleList()
                    else LocaleListCompat.forLanguageTags(tags[which])
                AppCompatDelegate.setApplicationLocales(locales)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ---------- 카메라 ----------

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = try {
                providerFuture.get()
            } catch (e: Exception) {
                Toast.makeText(this, getString(R.string.camera_error, e.message ?: ""), Toast.LENGTH_LONG).show()
                return@addListener
            }
            cameraProvider = provider

            if (extensionsManager != null) {
                bindUseCases()
                return@addListener
            }
            val extFuture = ExtensionsManager.getInstanceAsync(this, provider)
            extFuture.addListener({
                extensionsManager = try { extFuture.get() } catch (e: Exception) { null }
                qualityIndex = restoredQualityIndex()
                updateQualityButton()
                bindUseCases()
            }, ContextCompat.getMainExecutor(this))
        }, ContextCompat.getMainExecutor(this))
    }

    private fun baseSelector() = CameraSelector.Builder().requireLensFacing(lensFacing).build()

    private fun isQualityAvailable(mode: Int): Boolean {
        if (mode == ExtensionMode.NONE) return true
        val manager = extensionsManager ?: return false
        return try {
            manager.isExtensionAvailable(baseSelector(), mode)
        } catch (e: Exception) {
            false
        }
    }

    private fun firstAvailableQuality(): Int {
        qualityModes.forEachIndexed { i, mode -> if (isQualityAvailable(mode)) return i }
        return qualityModes.indexOf(ExtensionMode.NONE).coerceAtLeast(0)
    }

    private fun restoredQualityIndex(): Int {
        val saved = prefs.getInt(KEY_QUALITY, Int.MIN_VALUE)
        val at = qualityModes.indexOf(saved)
        return if (at >= 0 && isQualityAvailable(saved)) at else firstAvailableQuality()
    }

    private fun bindUseCases() {
        val provider = cameraProvider ?: return

        // 센서 전체(4:3) 중에서 화소 결합(비닝) 해상도를 우선 고른다.
        // 최대 해상도 모드는 화소가 작아져 어두운 곳에서 노이즈가 크게 늘기 때문에,
        // 기본 카메라 앱과 비슷하게 1600만 화소 이하 중 가장 큰 것을 쓴다.
        val binnedFirst = ResolutionFilter { sizes, _ ->
            val limit = 16_000_000L
            val sorted = sizes.sortedByDescending { it.width.toLong() * it.height }
            val within = sorted.filter { it.width.toLong() * it.height <= limit }
            val above = sorted.filter { it.width.toLong() * it.height > limit }
            (within + above)
        }

        val resolutionSelector = ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
            .setResolutionFilter(binnedFirst)
            .build()

        val preview = Preview.Builder()
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                    .build()
            )
            .build()
            .also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }

        val capture = ImageCapture.Builder()
            .setResolutionSelector(resolutionSelector)
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setFlashMode(ImageCapture.FLASH_MODE_OFF)
            .setTargetRotation(deviceRotation)
            .build()

        val mode = qualityModes.getOrElse(qualityIndex) { ExtensionMode.NONE }
        val selector = if (mode != ExtensionMode.NONE && isQualityAvailable(mode)) {
            try {
                extensionsManager!!.getExtensionEnabledCameraSelector(baseSelector(), mode)
            } catch (e: Exception) {
                baseSelector()
            }
        } else baseSelector()

        try {
            camera?.cameraInfo?.zoomState?.removeObservers(this)
            provider.unbindAll()
            val cam = provider.bindToLifecycle(this, selector, preview, capture)
            camera = cam
            imageCapture = capture
            cam.cameraInfo.zoomState.observe(this) { state ->
                binding.zoomText.text = String.format(Locale.US, "%.1fx", state.zoomRatio)
            }
        } catch (e: Exception) {
            if (mode != ExtensionMode.NONE) {
                qualityIndex = qualityModes.indexOf(ExtensionMode.NONE).coerceAtLeast(0)
                updateQualityButton()
                bindUseCases()
            } else {
                Toast.makeText(this, getString(R.string.camera_error, e.message ?: ""), Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * 미리보기 위 손가락 조작
     * - 두 손가락 벌리기 = 확대/축소
     * - 청록색 띠를 위아래로 끌기 = 가로 사진 위치 조절
     * - 한 번 탭 = 초점, 띠를 두 번 탭 = 위치 가운데로
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun setupPreviewGestures() {
        val slop = ViewConfiguration.get(this).scaledTouchSlop

        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val cam = camera ?: return true
                val state = cam.cameraInfo.zoomState.value ?: return true
                val target = (state.zoomRatio * detector.scaleFactor)
                    .coerceIn(state.minZoomRatio, state.maxZoomRatio)
                cam.cameraControl.setZoomRatio(target)
                return true
            }
        })

        val tapDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val cam = camera ?: return true
                val point = binding.previewView.meteringPointFactory.createPoint(e.x, e.y)
                cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(point).build())
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (binding.guideOverlay.isInsideLandscapeBand(e.x, e.y)) {
                    setLandscapeOffset(0f)
                    persistOffset()
                    Toast.makeText(this@MainActivity, R.string.landscape_reset, Toast.LENGTH_SHORT).show()
                    return true
                }
                return false
            }
        })

        var downX = 0f
        var downY = 0f
        var startOffset = 0f
        var inBand = false
        var dragging = false

        binding.guideOverlay.setOnTouchListener { _, event ->
            scaleDetector.onTouchEvent(event)

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    downY = event.y
                    startOffset = landscapeOffset
                    inBand = binding.guideOverlay.isInsideLandscapeBand(event.x, event.y)
                    dragging = false
                }

                MotionEvent.ACTION_MOVE -> {
                    if (inBand && !scaleDetector.isInProgress && event.pointerCount == 1) {
                        val dx = event.x - downX
                        val dy = event.y - downY
                        if (!dragging) {
                            val vertical = binding.guideOverlay.isDragAxisVertical()
                            val along = if (vertical) dy else dx
                            val across = if (vertical) dx else dy
                            if (abs(along) > slop && abs(along) > abs(across)) dragging = true
                        }
                        if (dragging) {
                            setLandscapeOffset(binding.guideOverlay.offsetAfterDrag(startOffset, dx, dy))
                        }
                    }
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        persistOffset()
                        dragging = false
                        inBand = false
                        return@setOnTouchListener true
                    }
                    inBand = false
                }
            }

            if (!dragging) tapDetector.onTouchEvent(event)
            true
        }

        binding.zoomText.setOnClickListener { camera?.cameraControl?.setZoomRatio(1f) }
    }

    private fun setLandscapeOffset(value: Float) {
        landscapeOffset = value.coerceIn(-1f, 1f)
        binding.guideOverlay.landscapeOffset = landscapeOffset
    }

    private fun persistOffset() {
        prefs.edit().putFloat(KEY_OFFSET, landscapeOffset).apply()
    }

    private fun flipCamera() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        if (!isQualityAvailable(qualityModes.getOrElse(qualityIndex) { ExtensionMode.NONE })) {
            qualityIndex = firstAvailableQuality()
            updateQualityButton()
        }
        bindUseCases()
    }

    private fun toggleRatio() {
        wideMode = !wideMode
        binding.guideOverlay.wideMode = wideMode
        prefs.edit().putBoolean(KEY_WIDE, wideMode).apply()
        updateRatioButton()
    }

    private fun updateRatioButton() {
        binding.ratioButton.text = if (wideMode) "9:16 · 16:9" else "3:4 · 4:3"
    }

    private fun cycleQuality() {
        val start = qualityIndex
        var next = qualityIndex
        for (i in 1..qualityModes.size) {
            next = (start + i) % qualityModes.size
            if (isQualityAvailable(qualityModes[next])) break
        }
        if (next == qualityIndex) {
            Toast.makeText(this, R.string.quality_unavailable, Toast.LENGTH_SHORT).show()
            return
        }
        qualityIndex = next
        prefs.edit().putInt(KEY_QUALITY, qualityModes[next]).apply()
        updateQualityButton()
        bindUseCases()
    }

    private fun updateQualityButton() {
        binding.qualityButton.text = when (qualityModes.getOrElse(qualityIndex) { ExtensionMode.NONE }) {
            ExtensionMode.AUTO -> getString(R.string.quality_auto)
            ExtensionMode.HDR -> getString(R.string.quality_hdr)
            ExtensionMode.NIGHT -> getString(R.string.quality_night)
            else -> getString(R.string.quality_none)
        }
    }

    // ---------- 촬영 ----------

    private fun takeDualShot() {
        val capture = imageCapture ?: return
        val useWideMode = wideMode
        val alsoOriginal = saveOriginal
        val offset = landscapeOffset
        pendingUp()

        capture.takePicture(cameraExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val bytes = try {
                    DualShotProcessor.readBytes(image)
                } catch (e: Exception) {
                    runOnUiThread { onFailed(e.message ?: "read error") }
                    image.close()
                    return
                }
                val rotation = image.imageInfo.rotationDegrees
                image.close()
                runOnUiThread { flashScreen() }

                processExecutor.execute {
                    try {
                        val result = DualShotProcessor.process(
                            this@MainActivity, bytes, rotation, useWideMode, alsoOriginal, offset
                        )
                        runOnUiThread { onSaved(result) }
                    } catch (e: Exception) {
                        runOnUiThread { onFailed(e.message ?: "unknown") }
                    } catch (e: OutOfMemoryError) {
                        runOnUiThread { onFailed(getString(R.string.out_of_memory)) }
                    }
                }
            }

            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { onFailed(exception.message ?: "capture error") }
            }
        })
    }

    private fun onSaved(result: DualShotProcessor.Result) {
        result.portrait?.let { binding.thumbPortrait.setImageBitmap(it) }
        result.landscape?.let { binding.thumbLandscape.setImageBitmap(it) }
        result.portraitUri?.let { lastPortraitUri = it }
        result.landscapeUri?.let { lastLandscapeUri = it }

        if (result.portraitUri == null && result.landscapeUri == null) {
            onFailed(getString(R.string.save_none))
            return
        }
        pendingDown()
    }

    private fun onFailed(message: String) {
        Toast.makeText(this, getString(R.string.save_failed, message), Toast.LENGTH_LONG).show()
        pendingDown()
    }

    private fun pendingUp() {
        pending++
        binding.progress.visibility = View.VISIBLE
    }

    private fun pendingDown() {
        pending = (pending - 1).coerceAtLeast(0)
        if (pending == 0) binding.progress.visibility = View.GONE
    }

    /** 셔터를 눌렀다는 시각적 신호 */
    private fun flashScreen() {
        val flash = binding.flashView
        flash.alpha = 0.75f
        flash.visibility = View.VISIBLE
        flash.animate().alpha(0f).setDuration(180L).withEndAction {
            flash.visibility = View.GONE
        }.start()
    }

    /** 이 앱으로 찍은 사진 목록에서 최신 세로/가로 사진을 썸네일로 표시 */
    private fun refreshThumbs() {
        processExecutor.execute {
            val shots = ShotGallery.load(this)
            val p = ShotGallery.latestPortrait(shots)
            val l = ShotGallery.latestLandscape(shots)
            val pb = p?.let { ShotGallery.loadScaled(this, it.uri, 256) }
            val lb = l?.let { ShotGallery.loadScaled(this, it.uri, 256) }
            runOnUiThread {
                lastPortraitUri = p?.uri
                lastLandscapeUri = l?.uri
                if (pb != null) binding.thumbPortrait.setImageBitmap(pb)
                else binding.thumbPortrait.setImageDrawable(null)
                if (lb != null) binding.thumbLandscape.setImageBitmap(lb)
                else binding.thumbLandscape.setImageDrawable(null)
            }
        }
    }

    private fun openReview(startUri: Uri?) {
        val intent = Intent(this, ReviewActivity::class.java)
        startUri?.let { intent.putExtra(ReviewActivity.EXTRA_START_URI, it.toString()) }
        reviewLauncher.launch(intent)
    }
}
