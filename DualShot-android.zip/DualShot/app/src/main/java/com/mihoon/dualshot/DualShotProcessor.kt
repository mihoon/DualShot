package com.mihoon.dualshot

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Matrix
import android.graphics.Rect
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.camera.core.ImageProxy
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * 한 번의 촬영(ImageProxy)에서 세로 사진과 가로 사진을 동시에 잘라내어 저장한다.
 *
 * 화질을 지키기 위해:
 * - 필요한 영역만 BitmapRegionDecoder로 잘라 읽는다 (전체 디코딩 → 재축소를 피함)
 * - JPEG 재압축 품질을 100으로 둔다 (한 번 더 압축되는 손실 최소화)
 * - 원본 저장은 카메라가 준 JPEG 바이트를 그대로 쓴다 (재압축 없음)
 */
object DualShotProcessor {

    /** 잘라낸 사진의 긴 변 상한 (메모리 보호). 요즘 폰 기본 카메라와 비슷한 수준 이상 */
    private const val MAX_LONG_SIDE = 6000
    private const val JPEG_QUALITY = 100
    private const val THUMB_LONG_SIDE = 512
    private const val FOLDER = "DualShot"

    data class Result(
        /** 화면 표시용 축소본 */
        val portrait: Bitmap?,
        val landscape: Bitmap?,
        val portraitUri: Uri?,
        val landscapeUri: Uri?,
        val originalUri: Uri?
    )

    /** wideMode = true → 9:16 / 16:9, false → 3:4 / 4:3 */
    fun process(
        context: Context,
        image: ImageProxy,
        wideMode: Boolean,
        saveOriginal: Boolean
    ): Result {
        val bytes = readBytes(image)
        val rotation = normalizeRotation(image.imageInfo.rotationDegrees)

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val rawW = bounds.outWidth
        val rawH = bounds.outHeight
        if (rawW <= 0 || rawH <= 0) throw IllegalStateException("이미지를 읽을 수 없습니다")

        // 바로 세웠을 때의 크기
        val swap = rotation == 90 || rotation == 270
        val upW = if (swap) rawH else rawW
        val upH = if (swap) rawW else rawH

        val (pw, ph) = if (wideMode) 9 to 16 else 3 to 4
        val (lw, lh) = if (wideMode) 16 to 9 else 4 to 3

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

        val portrait = cropSaveThumb(
            context, bytes, rawW, rawH, rotation,
            centerRect(upW, upH, pw, ph), "DualShot_${stamp}_V.jpg"
        )
        val landscape = cropSaveThumb(
            context, bytes, rawW, rawH, rotation,
            centerRect(upW, upH, lw, lh), "DualShot_${stamp}_H.jpg"
        )

        // 원본은 카메라가 준 JPEG 그대로 저장 (재압축 없음 = 화질 손실 없음)
        val originalUri = if (saveOriginal)
            saveStream(context, "DualShot_${stamp}_FULL.jpg") { it.write(bytes) } else null

        return Result(portrait.second, landscape.second, portrait.first, landscape.first, originalUri)
    }

    /** 잘라내기 → 저장 → 썸네일 생성 → 큰 비트맵 해제. 반환: (저장된 URI, 썸네일) */
    private fun cropSaveThumb(
        context: Context,
        bytes: ByteArray,
        rawW: Int,
        rawH: Int,
        rotation: Int,
        uprightRect: Rect,
        name: String
    ): Pair<Uri?, Bitmap?> {
        val bitmap = decodeCrop(bytes, rawW, rawH, rotation, uprightRect)
            ?: return null to null
        val uri = try {
            saveStream(context, name) { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
            }
        } catch (e: Exception) {
            null
        }
        val thumb = makeThumb(bitmap)
        if (thumb !== bitmap) bitmap.recycle()
        return uri to thumb
    }

    /** 바로 세운 좌표계의 잘라낼 영역을 원본 좌표계로 바꿔 그 부분만 디코딩한 뒤 회전 */
    private fun decodeCrop(
        bytes: ByteArray,
        rawW: Int,
        rawH: Int,
        rotation: Int,
        uprightRect: Rect
    ): Bitmap? {
        val rawRect = toRawRect(uprightRect, rawW, rawH, rotation)
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sampleFor(rawRect.width(), rawRect.height())
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        val cropped = decodeRegion(bytes, rawRect, opts)
            ?: fallbackCrop(bytes, rawRect, opts)
            ?: return null

        if (rotation == 0) return cropped
        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
        val rotated = try {
            Bitmap.createBitmap(cropped, 0, 0, cropped.width, cropped.height, matrix, true)
        } catch (e: OutOfMemoryError) {
            return cropped
        }
        if (rotated !== cropped) cropped.recycle()
        return rotated
    }

    @Suppress("DEPRECATION")
    private fun decodeRegion(bytes: ByteArray, rect: Rect, opts: BitmapFactory.Options): Bitmap? {
        var decoder: BitmapRegionDecoder? = null
        return try {
            decoder = BitmapRegionDecoder.newInstance(bytes, 0, bytes.size, false)
            decoder?.decodeRegion(rect, opts)
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        } finally {
            try { decoder?.recycle() } catch (e: Exception) { /* 무시 */ }
        }
    }

    /** 영역 디코딩이 안 되는 기기를 위한 대비책: 전체를 읽고 잘라낸다 */
    private fun fallbackCrop(bytes: ByteArray, rect: Rect, opts: BitmapFactory.Options): Bitmap? {
        val full = try {
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        } catch (e: OutOfMemoryError) {
            null
        } ?: return null

        val s = opts.inSampleSize.coerceAtLeast(1)
        val x = (rect.left / s).coerceIn(0, full.width - 1)
        val y = (rect.top / s).coerceIn(0, full.height - 1)
        val w = (rect.width() / s).coerceIn(1, full.width - x)
        val h = (rect.height() / s).coerceIn(1, full.height - y)

        return try {
            val out = Bitmap.createBitmap(full, x, y, w, h)
            if (out !== full) full.recycle()
            out
        } catch (e: Exception) {
            full
        }
    }

    private fun sampleFor(w: Int, h: Int): Int {
        var s = 1
        while (max(w, h) / s > MAX_LONG_SIDE) s *= 2
        return s
    }

    private fun makeThumb(src: Bitmap): Bitmap {
        val long = max(src.width, src.height)
        if (long <= THUMB_LONG_SIDE) return src
        val f = THUMB_LONG_SIDE.toFloat() / long
        val w = (src.width * f).roundToInt().coerceAtLeast(1)
        val h = (src.height * f).roundToInt().coerceAtLeast(1)
        return try {
            Bitmap.createScaledBitmap(src, w, h, true)
        } catch (e: Exception) {
            src
        }
    }

    /** 가운데 기준으로 주어진 비율에 맞는 최대 영역 (바로 세운 좌표계) */
    private fun centerRect(w: Int, h: Int, ratioW: Int, ratioH: Int): Rect {
        val target = ratioW.toDouble() / ratioH
        val srcRatio = w.toDouble() / h
        val cw: Int
        val ch: Int
        if (srcRatio > target) {
            ch = h
            cw = (h * target).roundToInt().coerceIn(1, w)
        } else {
            cw = w
            ch = (w / target).roundToInt().coerceIn(1, h)
        }
        val x = (w - cw) / 2
        val y = (h - ch) / 2
        return Rect(x, y, x + cw, y + ch)
    }

    /** 바로 세운 좌표계의 사각형을 원본(회전 전) 좌표계로 변환 */
    private fun toRawRect(r: Rect, rawW: Int, rawH: Int, rotation: Int): Rect {
        val out = when (rotation) {
            90 -> Rect(r.top, rawH - r.right, r.bottom, rawH - r.left)
            180 -> Rect(rawW - r.right, rawH - r.bottom, rawW - r.left, rawH - r.top)
            270 -> Rect(rawW - r.bottom, r.left, rawW - r.top, r.right)
            else -> Rect(r)
        }
        out.left = out.left.coerceIn(0, rawW - 1)
        out.top = out.top.coerceIn(0, rawH - 1)
        out.right = out.right.coerceIn(out.left + 1, rawW)
        out.bottom = out.bottom.coerceIn(out.top + 1, rawH)
        return out
    }

    private fun normalizeRotation(deg: Int): Int {
        val r = ((deg % 360) + 360) % 360
        return when {
            r < 45 || r >= 315 -> 0
            r < 135 -> 90
            r < 225 -> 180
            else -> 270
        }
    }

    private fun readBytes(image: ImageProxy): ByteArray {
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        return bytes
    }

    // ---------- 저장 ----------

    private fun saveStream(context: Context, name: String, write: (OutputStream) -> Unit): Uri? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + FOLDER)
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            try {
                resolver.openOutputStream(uri)?.use { write(it) }
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                uri
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                null
            }
        } else {
            @Suppress("DEPRECATION")
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                FOLDER
            )
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, name)
            try {
                FileOutputStream(file).use { write(it) }
                MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf("image/jpeg"), null)
                Uri.fromFile(file)
            } catch (e: Exception) {
                null
            }
        }
    }
}
