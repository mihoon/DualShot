package com.mihoon.dualshot

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.camera.core.ImageProxy
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * 한 번의 촬영(ImageProxy)에서 세로 사진과 가로 사진을 동시에 잘라내어 저장한다.
 *
 * - 센서 원본(4:3)을 바로 세운 뒤, 가운데를 기준으로
 *   세로(9:16 또는 3:4)와 가로(16:9 또는 4:3) 두 장을 잘라낸다.
 * - 저장 위치: 갤러리 > Pictures/DualShot/
 */
object DualShotProcessor {

    private const val MAX_LONG_SIDE = 4096   // 메모리 보호용 상한
    private const val JPEG_QUALITY = 95
    private const val FOLDER = "DualShot"

    data class Result(
        val portrait: Bitmap,
        val landscape: Bitmap,
        val portraitUri: Uri?,
        val landscapeUri: Uri?,
        val originalUri: Uri?
    )

    /** wideMode = true → 9:16 / 16:9, false → 3:4 / 4:3 */
    fun process(
        context: Context,
        image: ImageProxy,
        wideMode: Boolean,
        saveOriginal: Boolean
    ): Result {
        val upright = decodeUpright(image)

        val (pw, ph) = if (wideMode) 9 to 16 else 3 to 4
        val (lw, lh) = if (wideMode) 16 to 9 else 4 to 3

        val portrait = centerCrop(upright, pw, ph)
        val landscape = centerCrop(upright, lw, lh)

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val portraitUri = saveJpeg(context, portrait, "DualShot_${stamp}_V.jpg")
        val landscapeUri = saveJpeg(context, landscape, "DualShot_${stamp}_H.jpg")
        val originalUri = if (saveOriginal) saveJpeg(context, upright, "DualShot_${stamp}_FULL.jpg") else null

        return Result(portrait, landscape, portraitUri, landscapeUri, originalUri)
    }

    /** JPEG 바이트를 디코딩하고 CameraX가 알려주는 회전값을 적용해 바로 세운다. */
    private fun decodeUpright(image: ImageProxy): Bitmap {
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_LONG_SIDE) sample *= 2

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
            ?: throw IllegalStateException("이미지를 디코딩할 수 없습니다")

        val rotation = image.imageInfo.rotationDegrees
        if (rotation == 0) return raw

        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
        val rotated = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true)
        if (rotated !== raw) raw.recycle()
        return rotated
    }

    /** 가운데 기준으로 주어진 비율(ratioW:ratioH)에 맞춰 최대 크기로 잘라낸다. */
    fun centerCrop(src: Bitmap, ratioW: Int, ratioH: Int): Bitmap {
        val target = ratioW.toFloat() / ratioH
        val srcRatio = src.width.toFloat() / src.height

        val w: Int
        val h: Int
        if (srcRatio > target) {
            // 원본이 더 넓다 → 높이는 그대로, 폭을 줄인다
            h = src.height
            w = (h * target).roundToInt().coerceIn(1, src.width)
        } else {
            // 원본이 더 좁다 → 폭은 그대로, 높이를 줄인다
            w = src.width
            h = (w / target).roundToInt().coerceIn(1, src.height)
        }
        val x = (src.width - w) / 2
        val y = (src.height - h) / 2
        return Bitmap.createBitmap(src, x, y, w, h)
    }

    private fun saveJpeg(context: Context, bitmap: Bitmap, name: String): Uri? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            saveViaMediaStore(context, bitmap, name)
        } else {
            saveLegacy(context, bitmap, name)
        }
    }

    private fun saveViaMediaStore(context: Context, bitmap: Bitmap, name: String): Uri? {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + FOLDER)
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        try {
            resolver.openOutputStream(uri)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
            }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        return uri
    }

    @Suppress("DEPRECATION")
    private fun saveLegacy(context: Context, bitmap: Bitmap, name: String): Uri? {
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
            FOLDER
        )
        if (!dir.exists()) dir.mkdirs()
        val file = File(dir, name)
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
        }
        MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf("image/jpeg"), null)
        return Uri.fromFile(file)
    }
}
