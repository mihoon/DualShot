package com.mihoon.dualshot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.Surface
import android.view.View
import kotlin.math.min

/**
 * 미리보기 위에 세로/가로 촬영 범위를 그려주는 가이드.
 *
 * 이 뷰는 미리보기(3:4 박스)와 같은 크기로 겹쳐 놓는다.
 * - tall  : 박스 안에서 세로로 긴 영역
 * - wide  : 박스 안에서 가로로 긴 영역
 * 폰을 세워 들면 tall=세로사진, wide=가로사진이고,
 * 폰을 눕혀 들면 반대가 되므로 색과 라벨을 바꿔 그린다.
 */
class GuideOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    /** true → 9:16 / 16:9, false → 3:4 / 4:3 */
    var wideMode: Boolean = true
        set(value) { field = value; invalidate() }

    /** 기기의 물리적 회전 (Surface.ROTATION_0 / 90 / 180 / 270) */
    var deviceRotation: Int = Surface.ROTATION_0
        set(value) { if (field != value) { field = value; invalidate() } }

    private val colorPortrait = Color.parseColor("#FFB300")   // 세로: 주황
    private val colorLandscape = Color.parseColor("#26C6DA")  // 가로: 청록

    private val dimPaint = Paint().apply {
        color = Color.argb(110, 0, 0, 0)
        style = Paint.Style.FILL
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2f)
    }
    private val labelBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val labelText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = dp(12f)
        isFakeBoldText = true
    }

    private val tall = RectF()
    private val wide = RectF()

    private fun dp(v: Float) = v * resources.displayMetrics.density

    private fun computeRects() {
        val w = width.toFloat()
        val h = height.toFloat()
        val k = if (wideMode) 16f / 9f else 4f / 3f   // 긴 변 / 짧은 변

        // 세로로 긴 영역: 비율 1:k
        var tw = min(w, h / k)
        var th = tw * k
        if (th > h) { th = h; tw = th / k }
        tall.set((w - tw) / 2f, (h - th) / 2f, (w + tw) / 2f, (h + th) / 2f)

        // 가로로 긴 영역: 비율 k:1
        var ww = min(w, h * k)
        var wh = ww / k
        if (wh > h) { wh = h; ww = wh * k }
        wide.set((w - ww) / 2f, (h - wh) / 2f, (w + ww) / 2f, (h + wh) / 2f)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width == 0 || height == 0) return
        computeRects()

        val w = width.toFloat()
        val h = height.toFloat()

        // 두 영역의 합집합(십자 모양) 밖은 어둡게 처리
        canvas.drawRect(0f, 0f, tall.left, wide.top, dimPaint)            // 좌상
        canvas.drawRect(tall.right, 0f, w, wide.top, dimPaint)            // 우상
        canvas.drawRect(0f, wide.bottom, tall.left, h, dimPaint)          // 좌하
        canvas.drawRect(tall.right, wide.bottom, w, h, dimPaint)          // 우하

        val sideways = deviceRotation == Surface.ROTATION_90 || deviceRotation == Surface.ROTATION_270
        val tallColor = if (sideways) colorLandscape else colorPortrait
        val wideColor = if (sideways) colorPortrait else colorLandscape
        val tallLabel = context.getString(if (sideways) R.string.label_landscape else R.string.label_portrait)
        val wideLabel = context.getString(if (sideways) R.string.label_portrait else R.string.label_landscape)

        strokePaint.color = tallColor
        canvas.drawRect(tall, strokePaint)
        strokePaint.color = wideColor
        canvas.drawRect(wide, strokePaint)

        drawLabel(canvas, tallLabel, tallColor, tall.left + dp(6f), tall.top + dp(6f))
        drawLabel(canvas, wideLabel, wideColor, wide.right - dp(6f), wide.bottom - dp(6f), alignEnd = true)
    }

    private fun drawLabel(canvas: Canvas, text: String, color: Int, x: Float, y: Float, alignEnd: Boolean = false) {
        val pad = dp(5f)
        val tw = labelText.measureText(text)
        val th = labelText.textSize
        val left = if (alignEnd) x - tw - pad * 2 else x
        val top = if (alignEnd) y - th - pad * 2 else y
        labelBg.color = color
        canvas.drawRoundRect(left, top, left + tw + pad * 2, top + th + pad * 2, dp(4f), dp(4f), labelBg)
        canvas.drawText(text, left + pad, top + pad + th * 0.85f, labelText)
    }
}
