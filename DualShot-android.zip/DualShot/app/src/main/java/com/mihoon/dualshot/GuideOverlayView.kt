package com.mihoon.dualshot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.Surface
import android.view.View
import kotlin.math.abs
import kotlin.math.min

/**
 * 미리보기 위에 세로/가로 촬영 범위를 그려주는 가이드.
 *
 * 두 범위는 각자 여유가 있는 방향으로 옮길 수 있다.
 * - 사진(원본 4:3): 가로 띠는 위아래로, 세로 띠는 좌우로.
 * - 동영상(원본 가로 16:9): 가로는 화면 전체라 고정, 세로 띠만 좌우로.
 *
 * 두 띠는 가운데에서 겹치므로, 어느 띠를 옮길지는 손가락이 움직인 방향으로 정한다.
 */
class GuideOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    companion object {
        const val BAND_NONE = -1
        const val BAND_PORTRAIT = 0
        const val BAND_LANDSCAPE = 1
    }

    /** true → 9:16 / 16:9, false → 3:4 / 4:3 (사진 전용) */
    var wideMode: Boolean = true
        set(value) { field = value; invalidate() }

    /** 동영상 모드: 화면 전체가 가로 영상이고, 주황색 띠가 세로 영상 범위 */
    var videoMode: Boolean = false
        set(value) { if (field != value) { field = value; invalidate() } }

    /** 기기의 물리적 회전 (Surface.ROTATION_0 / 90 / 180 / 270) */
    var deviceRotation: Int = Surface.ROTATION_0
        set(value) { if (field != value) { field = value; invalidate() } }

    /** 전면 카메라처럼 미리보기가 좌우로 뒤집혀 보이는가 */
    var mirrored: Boolean = false
        set(value) { if (field != value) { field = value; invalidate() } }

    /** 세로 범위의 좌우 위치. -1 = 왼쪽 끝, 0 = 가운데, +1 = 오른쪽 끝 */
    var portraitOffset: Float = 0f
        set(value) {
            val v = value.coerceIn(-1f, 1f)
            if (field != v) { field = v; invalidate() }
        }

    /** 가로 범위의 위아래 위치. -1 = 위쪽 끝, 0 = 가운데, +1 = 아래쪽 끝 */
    var landscapeOffset: Float = 0f
        set(value) {
            val v = value.coerceIn(-1f, 1f)
            if (field != v) { field = v; invalidate() }
        }

    private val colorPortrait = Color.parseColor("#FFB300")   // 세로: 주황
    private val colorLandscape = Color.parseColor("#26C6DA")  // 가로: 청록

    private val dimPaint = Paint().apply {
        color = Color.argb(110, 0, 0, 0)
        style = Paint.Style.FILL
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2f)
    }
    private val gripPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2f)
        strokeCap = Paint.Cap.ROUND
    }
    private val labelBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val labelText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = dp(12f)
        isFakeBoldText = true
    }

    /** 화면 좌표계의 두 영역 (매 그리기마다 다시 계산) */
    private val portraitBand = RectF()
    private val landscapeBand = RectF()

    private fun dp(v: Float) = v * resources.displayMetrics.density

    /**
     * 미리보기(화면) 좌표계를 몇 도 돌리면 사진 좌표계가 되는가.
     *
     * 미리보기는 화면이 세로로 고정된 상태를 기준으로 그려지고,
     * 사진은 폰을 든 방향에 맞춰 바로 세워진다. 그 차이가 이 각도다.
     * (앞·뒤 카메라의 센서 방향과 무관하게 폰의 회전만으로 정해진다)
     */
    private fun photoRotation(): Int {
        if (videoMode) return 0
        return when (deviceRotation) {
            Surface.ROTATION_90 -> 270
            Surface.ROTATION_180 -> 180
            Surface.ROTATION_270 -> 90
            else -> 0
        }
    }

    /** 폰을 눕혀 들었는가 (그러면 화면의 가로로 긴 띠가 '세로 사진'이 된다) */
    private fun sideways(): Boolean {
        val t = photoRotation()
        return t == 90 || t == 270
    }

    /** 세로 범위가 화면의 세로축을 따라 움직이는가 */
    private fun portraitMovesVertically() = sideways()

    /** 가로 범위가 화면의 가로축을 따라 움직이는가 */
    private fun landscapeMovesHorizontally() = sideways()

    /**
     * 사진의 '오른쪽'(세로 범위가 커지는 방향)이 화면에서 +인지 -인지.
     * 전면 카메라는 미리보기가 좌우로 뒤집혀 보이므로 가로축일 때 한 번 더 뒤집는다.
     */
    private fun portraitSign(): Float {
        val base = when (photoRotation()) {
            90 -> -1f
            180 -> -1f
            270 -> 1f
            else -> 1f
        }
        return if (mirrored && !portraitMovesVertically()) -base else base
    }

    /** 사진의 '아래쪽'(가로 범위가 커지는 방향)이 화면에서 +인지 -인지 */
    private fun landscapeSign(): Float {
        val base = when (photoRotation()) {
            90 -> 1f
            180 -> -1f
            270 -> -1f
            else -> 1f
        }
        return if (mirrored && landscapeMovesHorizontally()) -base else base
    }

    private fun updateBands() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        if (videoMode) {
            // 가로 16:9 로 녹화하고, 세로 영상은 거기서 잘라낸다
            landscapeBand.set(0f, 0f, w, h)
            val bandW = h * 9f / 16f
            val left = (w - bandW) / 2f
            portraitBand.set(left, 0f, left + bandW, h)
            portraitBand.offset(portraitSign() * portraitOffset * (w - bandW) / 2f, 0f)
            return
        }

        val k = if (wideMode) 16f / 9f else 4f / 3f   // 긴 변 / 짧은 변

        // 화면에서 세로로 긴 영역 (1:k)
        var tw = min(w, h / k)
        var th = tw * k
        if (th > h) { th = h; tw = th / k }
        val tall = RectF((w - tw) / 2f, (h - th) / 2f, (w + tw) / 2f, (h + th) / 2f)

        // 화면에서 가로로 긴 영역 (k:1)
        var ww = min(w, h * k)
        var wh = ww / k
        if (wh > h) { wh = h; ww = wh * k }
        val wide = RectF((w - ww) / 2f, (h - wh) / 2f, (w + ww) / 2f, (h + wh) / 2f)

        if (sideways()) {
            // 화면의 가로로 긴 띠가 '세로 사진'이 된다
            portraitBand.set(wide)
            landscapeBand.set(tall)
            portraitBand.offset(0f, portraitSign() * portraitOffset * (h - wide.height()) / 2f)
            landscapeBand.offset(landscapeSign() * landscapeOffset * (w - tall.width()) / 2f, 0f)
        } else {
            portraitBand.set(tall)
            landscapeBand.set(wide)
            portraitBand.offset(portraitSign() * portraitOffset * (w - tall.width()) / 2f, 0f)
            landscapeBand.offset(0f, landscapeSign() * landscapeOffset * (h - wide.height()) / 2f)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width == 0 || height == 0) return
        updateBands()

        // 두 영역 밖은 어둡게
        canvas.save()
        canvas.clipOutRect(portraitBand)
        canvas.clipOutRect(landscapeBand)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dimPaint)
        canvas.restore()

        strokePaint.color = colorPortrait
        canvas.drawRect(portraitBand, strokePaint)
        strokePaint.color = colorLandscape
        canvas.drawRect(landscapeBand, strokePaint)

        // 옮길 수 있는 띠에는 손잡이를 그린다
        drawGrip(canvas, portraitBand, colorPortrait, gripIsVertical(BAND_PORTRAIT))
        if (!videoMode) {
            drawGrip(canvas, landscapeBand, colorLandscape, gripIsVertical(BAND_LANDSCAPE))
        }

        drawLabel(
            canvas, context.getString(R.string.label_portrait), colorPortrait,
            portraitBand.left + dp(6f), portraitBand.top + dp(6f)
        )
        drawLabel(
            canvas, context.getString(R.string.label_landscape), colorLandscape,
            landscapeBand.right - dp(6f), landscapeBand.bottom - dp(6f), alignEnd = true
        )
    }

    /** 손잡이 선의 방향 (움직이는 축과 직각으로 그린다) */
    private fun gripIsVertical(band: Int): Boolean = when (band) {
        BAND_PORTRAIT -> videoMode || !portraitMovesVertically()
        else -> landscapeMovesHorizontally()
    }

    private fun drawGrip(canvas: Canvas, band: RectF, color: Int, vertical: Boolean) {
        gripPaint.color = color
        val cx = band.centerX()
        val cy = band.centerY()
        val len = dp(11f)
        val gap = dp(5f)
        for (i in -1..1) {
            if (vertical) {
                val x = cx + i * gap
                canvas.drawLine(x, cy - len / 2f, x, cy + len / 2f, gripPaint)
            } else {
                val y = cy + i * gap
                canvas.drawLine(cx - len / 2f, y, cx + len / 2f, y, gripPaint)
            }
        }
    }

    private fun drawLabel(
        canvas: Canvas, text: String, color: Int,
        x: Float, y: Float, alignEnd: Boolean = false
    ) {
        val pad = dp(5f)
        val tw = labelText.measureText(text)
        val th = labelText.textSize
        val left = if (alignEnd) x - tw - pad * 2 else x
        val top = if (alignEnd) y - th - pad * 2 else y
        labelBg.color = color
        canvas.drawRoundRect(left, top, left + tw + pad * 2, top + th + pad * 2, dp(4f), dp(4f), labelBg)
        canvas.drawText(text, left + pad, top + pad + th * 0.85f, labelText)
    }

    // ---------- 바깥에서 쓰는 도우미 ----------

    /**
     * 손가락이 움직인 방향으로 어느 띠를 옮길지 정한다.
     * 두 띠가 가운데에서 겹치기 때문에 위치가 아니라 방향으로 구분한다.
     */
    fun bandForDrag(dx: Float, dy: Float): Int {
        val horizontal = abs(dx) > abs(dy)
        return when {
            videoMode -> if (horizontal) BAND_PORTRAIT else BAND_NONE
            portraitMovesVertically() -> if (horizontal) BAND_LANDSCAPE else BAND_PORTRAIT
            else -> if (horizontal) BAND_PORTRAIT else BAND_LANDSCAPE
        }
    }

    /** 끌기 시작 시점의 위치값 + 손가락 이동량 → 새 위치값 */
    fun offsetAfterDrag(band: Int, startOffset: Float, dx: Float, dy: Float): Float {
        updateBands()
        val w = width.toFloat()
        val h = height.toFloat()

        val delta = when {
            band == BAND_PORTRAIT && !portraitMovesVertically() -> {
                val slack = (w - portraitBand.width()) / 2f
                if (slack <= 0f) return startOffset else portraitSign() * dx / slack
            }
            band == BAND_PORTRAIT -> {
                val slack = (h - portraitBand.height()) / 2f
                if (slack <= 0f) return startOffset else portraitSign() * dy / slack
            }
            band == BAND_LANDSCAPE && videoMode -> return startOffset
            band == BAND_LANDSCAPE && landscapeMovesHorizontally() -> {
                val slack = (w - landscapeBand.width()) / 2f
                if (slack <= 0f) return startOffset else landscapeSign() * dx / slack
            }
            band == BAND_LANDSCAPE -> {
                val slack = (h - landscapeBand.height()) / 2f
                if (slack <= 0f) return startOffset else landscapeSign() * dy / slack
            }
            else -> return startOffset
        }
        return (startOffset + delta).coerceIn(-1f, 1f)
    }
}
