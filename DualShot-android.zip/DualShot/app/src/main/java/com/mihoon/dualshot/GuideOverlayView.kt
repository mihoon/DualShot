package com.mihoon.dualshot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.Surface
import android.view.View
import kotlin.math.min

/**
 * 미리보기 위에 세로/가로 촬영 범위를 그려주는 가이드.
 *
 * 두 범위 중 하나는 위치를 옮길 수 있다(cropOffset).
 * - 사진: 원본이 4:3이므로 **가로 띠**를 위아래로 옮긴다.
 * - 동영상: 원본이 가로 16:9이므로 **세로 띠**를 좌우로 옮긴다.
 */
class GuideOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    /** true → 9:16 / 16:9, false → 3:4 / 4:3 */
    var wideMode: Boolean = true
        set(value) { field = value; invalidate() }

    /** 동영상 모드: 화면 전체가 가로 영상이고, 주황색 띠가 세로 영상 범위 */
    var videoMode: Boolean = false
        set(value) { if (field != value) { field = value; invalidate() } }

    /** 기기의 물리적 회전 (Surface.ROTATION_0 / 90 / 180 / 270) */
    var deviceRotation: Int = Surface.ROTATION_0
        set(value) { if (field != value) { field = value; invalidate() } }

    /**
     * 움직일 수 있는 띠의 위치. 0 = 가운데.
     * 사진에서는 -1 위 / +1 아래, 동영상에서는 -1 왼쪽 / +1 오른쪽.
     */
    var cropOffset: Float = 0f
        set(value) {
            val v = value.coerceIn(-1f, 1f)
            if (field != v) { field = v; invalidate() }
        }

    private val colorPortrait = Color.parseColor("#FFB300")   // 세로: 주황
    private val colorLandscape = Color.parseColor("#26C6DA")  // 가로: 청록

    private val dimPaint = Paint().apply {
        color = Color.argb(110, 0, 0, 0)
        style = Paint.Style.FILL
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2f)
    }
    private val gripPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2f)
        strokeCap = Paint.Cap.ROUND
    }
    private val labelBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val labelText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = dp(12f)
        isFakeBoldText = true
    }

    /** 화면 좌표계의 두 영역 (매 그리기마다 다시 계산) */
    private val portraitBand = RectF()
    private val landscapeBand = RectF()

    private fun dp(v: Float) = v * resources.displayMetrics.density

    /** 폰을 눕혀 들었는가 (그러면 화면의 긴 띠가 '세로 사진'이 된다) */
    private fun sideways() =
        !videoMode && (deviceRotation == Surface.ROTATION_90 || deviceRotation == Surface.ROTATION_270)

    /**
     * 사진 기준 '아래쪽'이 화면에서 어느 방향인지.
     * 화면은 세로로 고정되어 있으므로 폰을 눕히면 축이 바뀐다.
     */
    private fun offsetSignSideways() = if (deviceRotation == Surface.ROTATION_90) -1f else 1f

    private fun updateBands() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        if (videoMode) {
            // 동영상은 가로 16:9 로 녹화하고, 세로 영상은 거기서 잘라낸다
            landscapeBand.set(0f, 0f, w, h)
            val bandW = h * 9f / 16f
            val left = (w - bandW) / 2f
            portraitBand.set(left, 0f, left + bandW, h)
            val slack = (w - bandW) / 2f
            portraitBand.offset(cropOffset * slack, 0f)
            return
        }

        val k = if (wideMode) 16f / 9f else 4f / 3f   // 긴 변 / 짧은 변

        // 화면에서 세로로 긴 영역 (1:k)
        var tw = min(w, h / k)
        var th = tw * k
        if (th > h) { th = h; tw = th / k }
        val tall = RectF((w - tw) / 2f, (h - th) / 2f, (w + tw) / 2f, (h + th) / 2f)

        // 화면에서 가로로 긴 영역 (k:1)
        var ww = min(w, h * k)
        var wh = ww / k
        if (wh > h) { wh = h; ww = wh * k }
        val wide = RectF((w - ww) / 2f, (h - wh) / 2f, (w + ww) / 2f, (h + wh) / 2f)

        if (sideways()) {
            portraitBand.set(wide)
            landscapeBand.set(tall)
            val slack = (w - landscapeBand.width()) / 2f
            landscapeBand.offset(offsetSignSideways() * cropOffset * slack, 0f)
        } else {
            portraitBand.set(tall)
            landscapeBand.set(wide)
            val slack = (h - landscapeBand.height()) / 2f
            landscapeBand.offset(0f, cropOffset * slack)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width == 0 || height == 0) return
        updateBands()

        // 두 영역 밖은 어둡게
        canvas.save()
        canvas.clipOutRect(portraitBand)
        canvas.clipOutRect(landscapeBand)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dimPaint)
        canvas.restore()

        strokePaint.color = colorPortrait
        canvas.drawRect(portraitBand, strokePaint)
        strokePaint.color = colorLandscape
        canvas.drawRect(landscapeBand, strokePaint)

        drawGrip(canvas)

        drawLabel(
            canvas, context.getString(R.string.label_portrait), colorPortrait,
            portraitBand.left + dp(6f), portraitBand.top + dp(6f)
        )
        drawLabel(
            canvas, context.getString(R.string.label_landscape), colorLandscape,
            landscapeBand.right - dp(6f), landscapeBand.bottom - dp(6f), alignEnd = true
        )
    }

    /** 움직일 수 있는 띠에 손잡이 모양을 그린다 */
    private fun drawGrip(canvas: Canvas) {
        val band = movableBand()
        gripPaint.color = if (videoMode) colorPortrait else colorLandscape
        val cx = band.centerX()
        val cy = band.centerY()
        val len = dp(11f)
        val gap = dp(5f)
        for (i in -1..1) {
            if (!isDragAxisVertical()) {
                val x = cx + i * gap
                canvas.drawLine(x, cy - len / 2f, x, cy + len / 2f, gripPaint)
            } else {
                val y = cy + i * gap
                canvas.drawLine(cx - len / 2f, y, cx + len / 2f, y, gripPaint)
            }
        }
    }

    private fun drawLabel(
        canvas: Canvas, text: String, color: Int,
        x: Float, y: Float, alignEnd: Boolean = false
    ) {
        val pad = dp(5f)
        val tw = labelText.measureText(text)
        val th = labelText.textSize
        val left = if (alignEnd) x - tw - pad * 2 else x
        val top = if (alignEnd) y - th - pad * 2 else y
        labelBg.color = color
        canvas.drawRoundRect(left, top, left + tw + pad * 2, top + th + pad * 2, dp(4f), dp(4f), labelBg)
        canvas.drawText(text, left + pad, top + pad + th * 0.85f, labelText)
    }

    // ---------- 바깥에서 쓰는 도우미 ----------

    /** 지금 움직일 수 있는 띠 */
    private fun movableBand(): RectF = if (videoMode) portraitBand else landscapeBand

    /** 그 지점이 움직일 수 있는 띠 안인가 (끌기 시작 판정용) */
    fun isInsideMovableBand(x: Float, y: Float): Boolean {
        updateBands()
        return movableBand().contains(x, y)
    }

    /** 끌기 시작 시점의 위치값 + 손가락 이동량 → 새 위치값 */
    fun offsetAfterDrag(startOffset: Float, dx: Float, dy: Float): Float {
        updateBands()
        val band = movableBand()
        return if (videoMode) {
            val slack = (width - band.width()) / 2f
            if (slack <= 0f) startOffset
            else (startOffset + dx / slack).coerceIn(-1f, 1f)
        } else if (sideways()) {
            val slack = (width - band.width()) / 2f
            if (slack <= 0f) startOffset
            else (startOffset + offsetSignSideways() * dx / slack).coerceIn(-1f, 1f)
        } else {
            val slack = (height - band.height()) / 2f
            if (slack <= 0f) startOffset
            else (startOffset + dy / slack).coerceIn(-1f, 1f)
        }
    }

    /** 손가락 이동이 위치 조절 방향인지 (끌기인지 화면 탭인지 구분할 때) */
    fun isDragAxisVertical() = !videoMode && !sideways()
}
