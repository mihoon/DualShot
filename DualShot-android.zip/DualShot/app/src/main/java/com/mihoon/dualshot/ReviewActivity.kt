package com.mihoon.dualshot

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.mihoon.dualshot.databinding.ActivityReviewBinding
import java.io.File
import kotlin.math.max

/**
 * 방금 찍은 사진(세로/가로/원본)을 전체화면으로 보여주고 삭제할 수 있는 화면.
 */
class ReviewActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URIS = "uris"
        const val EXTRA_LABELS = "labels"
        const val EXTRA_START = "start"
        const val RESULT_DELETED_URIS = "deleted"
    }

    private lateinit var binding: ActivityReviewBinding
    private val uris = ArrayList<String>()
    private val labels = ArrayList<String>()
    private val deleted = ArrayList<String>()
    private var index = 0
    private var current: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        uris.addAll(intent.getStringArrayListExtra(EXTRA_URIS) ?: arrayListOf())
        labels.addAll(intent.getStringArrayListExtra(EXTRA_LABELS) ?: arrayListOf())
        index = intent.getIntExtra(EXTRA_START, 0).coerceIn(0, max(0, uris.size - 1))

        if (uris.isEmpty()) { finish(); return }

        binding.closeButton.setOnClickListener { finishWithResult() }
        binding.prevButton.setOnClickListener { show(index - 1) }
        binding.nextButton.setOnClickListener { show(index + 1) }
        binding.deleteButton.setOnClickListener { confirmDelete() }
        binding.shareButton.setOnClickListener { share() }

        show(index)
    }

    private fun show(i: Int) {
        if (uris.isEmpty()) { finishWithResult(); return }
        index = ((i % uris.size) + uris.size) % uris.size
        val uri = Uri.parse(uris[index])

        current?.recycle()
        current = loadBitmap(uri)
        binding.imageView.setImageBitmap(current)

        binding.labelText.text = getString(R.string.review_label, labels[index], index + 1, uris.size)
        binding.prevButton.isVisible = uris.size > 1
        binding.nextButton.isVisible = uris.size > 1
    }

    private fun loadBitmap(uri: Uri): Bitmap? {
        return try {
            // 큰 사진은 화면 크기에 맞게 줄여서 읽는다 (메모리 보호)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            val screen = max(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > screen * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        } catch (e: Exception) {
            null
        }
    }

    private fun confirmDelete() {
        val label = labels[index]
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_title)
            .setMessage(getString(R.string.delete_message, label))
            .setPositiveButton(R.string.delete_this) { _, _ -> deleteCurrent() }
            .setNeutralButton(R.string.delete_all) { _, _ -> deleteAll() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun deleteUri(uriString: String): Boolean {
        val uri = Uri.parse(uriString)
        return try {
            if (uri.scheme == "file") {
                val f = File(uri.path ?: return false)
                val ok = f.delete()
                if (ok) android.media.MediaScannerConnection.scanFile(this, arrayOf(f.absolutePath), null, null)
                ok
            } else {
                contentResolver.delete(uri, null, null) > 0
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun deleteCurrent() {
        val target = uris[index]
        if (deleteUri(target)) {
            deleted.add(target)
            uris.removeAt(index)
            labels.removeAt(index)
            Toast.makeText(this, R.string.deleted_one, Toast.LENGTH_SHORT).show()
            if (uris.isEmpty()) finishWithResult() else show(index)
        } else {
            Toast.makeText(this, R.string.delete_failed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteAll() {
        var count = 0
        val remaining = ArrayList<String>()
        val remainingLabels = ArrayList<String>()
        uris.forEachIndexed { i, u ->
            if (deleteUri(u)) { deleted.add(u); count++ } else { remaining.add(u); remainingLabels.add(labels[i]) }
        }
        uris.clear(); uris.addAll(remaining)
        labels.clear(); labels.addAll(remainingLabels)
        Toast.makeText(this, getString(R.string.deleted_n, count), Toast.LENGTH_SHORT).show()
        if (uris.isEmpty()) finishWithResult() else show(0)
    }

    private fun share() {
        val uri = Uri.parse(uris[index])
        if (uri.scheme == "file") {
            Toast.makeText(this, R.string.share_unavailable, Toast.LENGTH_SHORT).show()
            return
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, getString(R.string.share)))
    }

    private fun finishWithResult() {
        val data = Intent().putStringArrayListExtra(RESULT_DELETED_URIS, deleted)
        setResult(Activity.RESULT_OK, data)
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        finishWithResult()
    }

    override fun onDestroy() {
        super.onDestroy()
        current?.recycle()
        current = null
    }
}
