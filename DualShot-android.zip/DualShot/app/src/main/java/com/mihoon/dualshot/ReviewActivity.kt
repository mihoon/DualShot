package com.mihoon.dualshot

import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.mihoon.dualshot.databinding.ActivityReviewBinding
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.max

/**
 * 이 앱으로 찍은 사진 전체를 전체화면으로 넘겨보고, 확대하고, 삭제하는 화면.
 */
class ReviewActivity : AppCompatActivity() {

    companion object {
        /** 처음에 보여줄 사진의 URI (없으면 가장 최근 사진부터) */
        const val EXTRA_START_URI = "start_uri"
        const val RESULT_CHANGED = "changed"
    }

    private lateinit var binding: ActivityReviewBinding
    private val io = Executors.newSingleThreadExecutor()

    private var shots = ArrayList<ShotGallery.Shot>()
    private var index = 0
    private var current: Bitmap? = null
    private var changed = false
    private var pendingDelete: ShotGallery.Shot? = null

    /** Android 10 이상에서 삭제 권한을 사용자에게 물어야 할 때 */
    private val deleteConsent =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            val target = pendingDelete
            pendingDelete = null
            if (result.resultCode == Activity.RESULT_OK && target != null) {
                removeFromList(target)
                Toast.makeText(this, R.string.deleted_one, Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, R.string.delete_failed, Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.closeButton.setOnClickListener { finishWithResult() }
        binding.prevButton.setOnClickListener { show(index - 1) }
        binding.nextButton.setOnClickListener { show(index + 1) }
        binding.deleteButton.setOnClickListener { confirmDelete() }
        binding.shareButton.setOnClickListener { share() }
        binding.imageView.onSwipe = { direction -> show(index + direction) }

        val startUri = intent.getStringExtra(EXTRA_START_URI)

        io.execute {
            val loaded = ShotGallery.load(this)
            runOnUiThread {
                shots = ArrayList(loaded)
                if (shots.isEmpty()) {
                    Toast.makeText(this, R.string.no_photos, Toast.LENGTH_SHORT).show()
                    finishWithResult()
                    return@runOnUiThread
                }
                val start = shots.indexOfFirst { it.uri.toString() == startUri }
                show(if (start >= 0) start else 0)
            }
        }
    }

    private fun show(i: Int) {
        if (shots.isEmpty()) { finishWithResult(); return }
        index = ((i % shots.size) + shots.size) % shots.size
        val shot = shots[index]

        binding.labelText.text = getString(R.string.review_label, shot.label, index + 1, shots.size)
        binding.prevButton.isVisible = shots.size > 1
        binding.nextButton.isVisible = shots.size > 1

        val screen = max(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)
        val wanted = shot.uri
        io.execute {
            val bmp = ShotGallery.loadScaled(this, wanted, screen * 2)
            runOnUiThread {
                // 그 사이에 다른 사진으로 넘어갔으면 버린다
                if (shots.getOrNull(index)?.uri != wanted) {
                    bmp?.recycle()
                    return@runOnUiThread
                }
                current?.recycle()
                current = bmp
                binding.imageView.setImageBitmap(bmp)
            }
        }
    }

    // ---------- 삭제 ----------

    private fun confirmDelete() {
        val shot = shots.getOrNull(index) ?: return
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_title)
            .setMessage(getString(R.string.delete_message, shot.label))
            .setPositiveButton(R.string.delete) { _, _ -> deleteCurrent(shot) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun deleteCurrent(shot: ShotGallery.Shot) {
        val uri = shot.uri
        try {
            if (uri.scheme == "file") {
                val f = File(uri.path ?: return)
                if (f.delete()) {
                    android.media.MediaScannerConnection.scanFile(this, arrayOf(f.absolutePath), null, null)
                    removeFromList(shot)
                    Toast.makeText(this, R.string.deleted_one, Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, R.string.delete_failed, Toast.LENGTH_SHORT).show()
                }
                return
            }

            val deleted = contentResolver.delete(uri, null, null)
            if (deleted > 0) {
                removeFromList(shot)
                Toast.makeText(this, R.string.deleted_one, Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, R.string.delete_failed, Toast.LENGTH_SHORT).show()
            }
        } catch (e: SecurityException) {
            // 앱을 다시 설치하면 예전 사진의 소유권이 사라져 시스템에 삭제 허가를 받아야 한다
            requestDeleteConsent(shot, e)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.delete_failed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestDeleteConsent(shot: ShotGallery.Shot, e: SecurityException) {
        pendingDelete = shot
        try {
            val sender = when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.R ->
                    android.provider.MediaStore.createDeleteRequest(
                        contentResolver, listOf(shot.uri)
                    ).intentSender
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && e is RecoverableSecurityException ->
                    e.userAction.actionIntent.intentSender
                else -> null
            }
            if (sender == null) {
                pendingDelete = null
                Toast.makeText(this, R.string.delete_failed, Toast.LENGTH_SHORT).show()
                return
            }
            deleteConsent.launch(IntentSenderRequest.Builder(sender).build())
        } catch (ex: Exception) {
            pendingDelete = null
            Toast.makeText(this, R.string.delete_failed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun removeFromList(shot: ShotGallery.Shot) {
        val at = shots.indexOfFirst { it.uri == shot.uri }
        if (at >= 0) shots.removeAt(at)
        changed = true
        if (shots.isEmpty()) finishWithResult() else show(if (at in shots.indices) at else 0)
    }

    private fun share() {
        val shot = shots.getOrNull(index) ?: return
        if (shot.uri.scheme == "file") {
            Toast.makeText(this, R.string.share_unavailable, Toast.LENGTH_SHORT).show()
            return
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, shot.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, getString(R.string.share)))
    }

    private fun finishWithResult() {
        setResult(Activity.RESULT_OK, Intent().putExtra(RESULT_CHANGED, changed))
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        finishWithResult()
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdown()
        current?.recycle()
        current = null
    }
}
